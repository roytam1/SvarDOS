/*
    Help screen displayed on console while invoking zBoy from console mode with --help.
    This file is part of the zBoy project.
    Copyright (C) Mateusz Viste 2010,2011,2012
*/

#ifndef ZBOY_ABOUT_SENTINEL
  #define ZBOY_ABOUT_SENTINEL
  void printhelp(void);
#endif
