/*
    Word-wrapping function
    Author: Mateusz Viste
    Last modified: 13 Aug 2011

   Note, that the function will modify the char array you will pass to it!
*/

void WordWrap(char *TextToWrap, int WrapValue, char *result);
