PCAE (DOS) source distribution
--------------------------------------------

This archive contains all the source files needed to build PCAE in
Borland Pascal 7.0. Before compiling you should first place my Pascal
.TPL libraries into your BP/BIN folder. They fix numerous bugs in the
initial release of BP7 and allow the emulator to run properly.

All of MY source code is released under the GPL (see file "COPYING").

John Dullea
December, 2000
