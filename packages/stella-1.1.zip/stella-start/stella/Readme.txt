
This is release 1.1 of Stella.  You'll find the Stella Users Manual in 
the docs subdirectory.  If you'd like to verify that you have the latest
release of Stella visit the web site at:

  http://stella.atari.org

If you find any problems please let me know.

Bradford W. Mott
February 26, 1999
bwmott@acm.org

