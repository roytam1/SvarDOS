#define LZOP_VERSION            0x0960
#define LZOP_VERSION_STRING     "0.96"
#define LZOP_VERSION_DATE       "Mar 13th 1998"
