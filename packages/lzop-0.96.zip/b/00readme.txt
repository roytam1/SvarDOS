Simple make drivers for DOS, Windows, OS/2 and other systems
============================================================

This directory contains a bunch of simple make drivers - I've tried
to make them as foolproof as possible.

To build lzop for your system type `b\OS\COMPILER' in the base directory,
e.g. `b\dos32\wc105' will build the 32-bit DOS Watcom C v10.5 version.

All scripts expect that the LZO library has been installed and built
in the directory ..\lzo-1.03. You can also set the environment variable
`LZODIR' to point to your LZO directory, e.g. `set LZODIR=c:\src\lzo-1.03'

Please send me your additional/improved versions.


Overview:
---------

b\dos16\mc70.bat        Microsoft C 7.0                       (1)
b\dos16\wc105.bat       Watcom C 10.5                         (1)

b\dos32\dj2.bat         djgpp v2 + gcc
b\dos32\emx.bat         emx + gcc
b\dos32\wc105.bat       Watcom C 10.5

b\os2\wc105.cmd         Watcom C 10.5                         (2)

b\win16\wc105.bat       Watcom C 10.5                         (1)

b\win32\cdk.bat         Cygnus Win32 + gcc
b\win32\mc110.bat       Microsoft C 11.00      Visual C 5.0
b\win32\wc105.bat       Watcom C 10.5


Notes:
  (1) 16-bit versions are not officially supported
  (2) not tested as of version 0.96


