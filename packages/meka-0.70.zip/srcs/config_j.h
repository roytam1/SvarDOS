//-----------------------------------------------------------------------------
// MEKA - config_j.h
// Configuration File: Joypad/stick Drivers - Headers
//-----------------------------------------------------------------------------

int     Config_Driver_Joy_Str_to_Int (char *DriverName);
char *  Config_Driver_Joy_Int_to_Str (int a);

//-----------------------------------------------------------------------------

