//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Meka.rc

#define IDD_SETUP                       9
#define IDD_CONSOLE                     101
#define IDC_CONSOLE_TEXT                1001
#define IDC_CONSOLE_CLEAR               1002
#define IDC_CONSOLE_COPY                1003
#define IDC_CONSOLE_QUIT                1004
#define IDC_SETUP_SOUNDCARDS            1005
#define IDC_SETUP_SOUND_TEXT_1          1006
#define IDC_CONSOLE_RUN                 1006
#define IDC_SETUP_SOUND_TEXT_2          1007
#define IDC_CONSOLE_MEKA_VERSION        1007
#define IDC_CONSOLE_INFO                1007
#define IDC_SETUP_SOUNDRATE             1008
#define IDC_SETUP_SOUND_TEXT_3          1009
#define IDC_SETUP_LANGUAGE              1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
