/****************************************************************/
/*    FM voice editor version 0.01 for MEKA                     */
/*                              Programmed by Hiromitsu Shioya  */
/****************************************************************/

#ifndef __FMEDITOR_H__
#define __FMEDITOR_H__

void    FM_Editor_Init (void);
void    FM_Editor_Switch (void);

#endif

/* EOF */

