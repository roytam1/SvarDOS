
2005/04/03

Those miscellaenous development docs may be badly outdated.
Ask for anything you need on the MEKA forum!
I have heap of unsorted docs, things in my mind, things wrote on paper...

-Omar
