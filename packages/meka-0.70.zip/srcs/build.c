char MEKA_BUILD_DATE[] = "3 April 2005";
char MEKA_BUILD_TIME[] = "23:20:34";
