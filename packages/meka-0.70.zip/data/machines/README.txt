
2005/04/02

This is the most outdated thing ever. I have more I never finished
cleaning. I kinda started disliking this idea of putting random
shots on the interface. I'd rather have clean pictures made from
the same angle, or drawn rendition of systems.

I converted the files to GIF format now but I don't know if Allegro's
grabber eat GIF. Originally they were in TGA.

-Omar
