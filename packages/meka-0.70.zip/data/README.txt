
2005/04/02

Some of the data included in MEKA.DAT file.

Note:
- MEKA-WIP.DAT is the work datafile.
- MEKA.DAT is the end-user datafile stripped of names.
Always work on MEKA-WIP.DAT then save stripped to MEKA.DAT.

See DATA.H for a full list of the data entries.
Use Allegro GRABBER to manipulate DAT files.
Encryption password is:
    west0ne0000000
:)

It may not be trivial for someone other than me to rebuild a 
MEKA.DAT file from stratch, given that I have various files
scattered on my computer (hacked BIOS images, etc), but you can
always add or replace existing data and keeping the older one
intact using Allegro GRABBER tool.

If you're concerned by this and you want to clean this part,
feel free to discuss with me. BIOS should eventually be removed
from there in favor of real, non-hacked BIOS (with potentially
BIOS hacks hardcoded in MEKA and enablable at will).

-Omar
