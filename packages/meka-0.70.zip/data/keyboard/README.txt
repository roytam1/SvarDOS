
2005/04/02

This is a drawing of SC-3000 keyboard (also known as SK-1100 when
sold separately).

This looked fairly accurate when I originally did it (last update 
was on 1999/01/17) but now I'd say it's begging for improvement.

Palette usage is a problem, though, as the palette is global and used 
for other GUI graphics (won't be a problem when switching to hi-color).
I made 3 skins but never used them. The last one (black) may be a 
better rendition of the most common SC-3000 color scheme than the
currently used one.

-Omar
