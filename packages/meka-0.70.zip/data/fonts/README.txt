
2005/04/02

This is a mess. Note how I modified certain fonts
to move around some accentued character.
On font 0 (the big one) I also manually added 3 glyphs
for usage in the GUI:
    - Little star (for closing windows)
    - Check (for when a menuitem is checked)
    - Modified '>' (when a menuitem lead to a submenu)

Eventually, fonts should be replaced by some having those
glyphs (refered in Unicode notation):
    - Latin character set (U-00 to U-7F)
    - Extended Latin (U-80 to U-FF)
    - Selected asian characters set:
        - Japanese katakana + hiragana
        - Japanese kanjis (perhaps not all but only those used in game titles + localization)
        - Korean characters (for some game titles) // less important

-Omar