#define UPX_VERSION_HEX         0x040001        /* 04.00.01 */
#define UPX_VERSION_STRING      "4.0.1"
#define UPX_VERSION_STRING4     "4.01"
#define UPX_VERSION_DATE        "Nov 16th 2022"
#define UPX_VERSION_DATE_ISO    "2022-11-16"
#define UPX_VERSION_YEAR        "2022"

/* vim:set ts=4 sw=4 et: */
