#ifndef __ICON_H__
#define __ICON_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


char *a_Icon_load();


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __ICON_H__ */
