#ifndef __UNICOWS_H__
#define __UNICOWS_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


void a_Unicows_check(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __UNICOWS_H__ */
