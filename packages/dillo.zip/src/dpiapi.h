
void a_Dpiapi_dialog(BrowserWindow *bw, char *server, char *dpip_tag);

