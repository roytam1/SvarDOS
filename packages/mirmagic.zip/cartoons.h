/***********************************************************
* Mirror Magic -- McDuffin's Revenge                       *
*----------------------------------------------------------*
* (c) 1994-2001 Artsoft Entertainment                      *
*               Holger Schemel                             *
*               Detmolder Strasse 189                      *
*               33604 Bielefeld                            *
*               Germany                                    *
*               e-mail: info@artsoft.org                   *
*----------------------------------------------------------*
* cartoons.h                                               *
***********************************************************/

#ifndef CARTOONS_H
#define CARTOONS_H

void InitAnimation(void);
void StopAnimation(void);
void DoAnimation(void);

#endif
