#ifndef MONSPEAK_H
#define MONSPEAK_H

#include "externs.h"

bool mons_speaks(struct monsters *monster);

#endif
