#define SPELL_GB 1
#define SPELL_US 2
#define LATIN1 4

extern int lang;

void getlang();
void spellword(char *word);
