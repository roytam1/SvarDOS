#ifndef config_h
#define config_h
#include "config2.h"
#endif
