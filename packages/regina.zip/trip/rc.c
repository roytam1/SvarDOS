int main( int argc, char *argv[] ) { exit (atoi(argv[1])) ; } 
