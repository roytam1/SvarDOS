
                          **************************
                          *  HAPPYLAND ADVENTURES  *
                          **************************

                        a game written by Johan Peitz

                     brought to you by Free Lunch Design

                                  (c) 2000

                       art from Ari Feltman's SpriteLib


GENERAL

    Welcome to Happyland Adventures! This game is completely free. You
    may play it as much as you like without paying a single buck. In
    exchange for playing it, you are instead asked for a small favour.
    You are encouraged to send any comments you might have about this
    game. If you like it or not or if you have any suggestions.

    This game was originally written for an amateur game programming
    contest at www.gamedev.net. Happyland Adventures won the contest,
    it also got an award for 'best use of SpriteLib'.


DISTRIBUTING

    Happyland Adventures is freeware, anybody may (and should) play it.
    Therefore, you are encouraged to distribute this game (in it's
    original form) like crazy. Upload to every website and bbs you know,
    give a copy to all your friends, etc.. However, this game may not be
    included in a compilation or any other kind of commercial package
    without the permission from the author. See contact near the end of
    this document.
  

DISCLAIMER
                  
    I do not accept responsibility for any effects, adverse or otherwise, 
    that this software may have on you, your computer, your sanity, your 
    dog, or anything else that you can think of. Use it at your own risk. 
    I have, however, never experienced any trouble with it.
                           

DESCRIPTION

    Happyland Adventures is a classic jump'n'run combined with original
    puzzle elements, a game full of surprises. Explore the big levels
    and collect various fruits for bonus. Save the Happylanders in order
    to rid the world of evilness.


HARDWARE REQUIREMENTS

    Required:
      * PC 486 (a fast one)
      * 4 MB RAM
      * VGA-card/display.

    Recommended:
      * Pentium
      * 4 MB RAM
      * VGA-card/display.
      * gamepad
      * SB combatible soundcard  


INSTALLING AND STARTING THE GAME

    Install the game by unzipping the zipfile into a desired directory. If
    you're reading this you have probably already done this.

    There are a few command line options you can use:
       /nosound                 turns all sound off
       /reset                   resets all saved data,
                                including highscore tables
       /level <filename>        play happyland using custom level <filename>
       /levelfile <filename>    play happyland using the levels specified
                                int <filename>, see further down for
                                creating levelfiles

    When starting the game you will be shown a screen where the game
    precalculates values and sets up memory for later use. You can follow
    the progress. (This should only take a short while.) When done you
    end up at the titlescreen.


THE PLOT

    Sun shines upon Happyland. Everyone is happy, as always. But if you look
    closely enough you can see that something is astray. The happylanders
    seem to be somewhat confused, they just hang around, doing nothing. With
    fear you realise that it's been about a hundred years since the last time
    this happened, the curse of Happyland! Now it's up to you to bring the
    happylanders to saftey, else happiness as we know it will forever perish.


THE TITLESCREEN

    The titlescreen will present you with a menu of the following format:

      PLAY
      OPTIONS
      HELP ME
      EXIT

    Use the arrowkeys to navigate the menu. The current selection is
    indicated by a small creature to the left of the selection. Use enter
    or space to select. EXIT exits the game. HELP ME shows a quick tutorial,
    OPTIONS takes you to another menu where you can customize the game.
    PLAY starts the game.


THE OPTIONS-SCREEN

    Here you can customize keys and controls. Adjust sound and music output.
    Navigate with up and down arrows and use left and right arrows to adjust
    the highlighted selection. Press enter or space to select.


CONTROLS

    Default keys are as follows:

      Key         Action        Key         Action

      Up          UP            Jump        left ALT
      Down        DOWN          Sneak       left CONTROL
      Left        LEFT          Talk        left SHIFT
      Right       RIGHT

      Screenshot  F12
      Pause       PAUSE
      Quit        ESC

    Screenshots will be stored as HAPPY???.PCX, where ??? is the number
    of the screenshot taken.

    If you want to use a gamepad (recommended), simply press the
    direction/button instead of a key whilst setting the controls from the
    OPTIONS-menu.

    ( Note: UP and DOWN is not used in the game. This means that if you
            like, you can put JUMP and TALK on these instead. )


PLAYING

    The goal of each level is to save the Happylanders scattered over the
    level. When you have saved enough Happylanders the level exit will open.
    The number of Happylanders the you must save is shown in the top right
    corner of the screen, just below the time indicator.

    If you save _all_ Happylanders on a level, enemies will turn into coins.

    Tip! There is often more to do on a level even if you have opened the
    door. Ie, don't exit immediately. :)  Each level has two exits, one of
    them is often cleverly hidden, holding bonuses if you find it.

    Each level must be completed within a specified amount of time. You can
    see how much time is left in the top right corner of the screen.

    Old wise men also inhabit Happyland. Make sure you talk to them. They
    might give you useful hints.


PICKUPS

    Most items you can pickup will only give you points. There are however a
    few that give you special powers.

        HEART           increases your energy
        TIMEGLASS       recieve extra time
        COIN            collect all to access bonusroom
        BLUE POTION     invunerability for a short while
        LOG-G SHOES     jump higher and farther


LOADING ADDITONAL LEVELS INTO HAPPYLAND

  This is very simpe. Create a textfile, it should start with the text
  .happyland on the first line and .end on the last. Between these lines
  you simply enter the path and name of the levels you want to play. It
  could look like this:

        .happyland
        maps\my_first.map
        maps\second.map
        maps\caves.map
        maps\jungle.map
        maps\showdown.map
        .end

  When your file is complete, save it and start Happyland from the prompt
  using the following syntax:

        C:\HAPPY> happy /levelfile <filename>

  Where <filename> is the name of the textfile you just created. For more
  info, read MAPED.TXT.


TROUBLESHOOTING / FAQ

    Q: There's no sound!
    A: The sound should autodetect. Something might be wrong. There's no
       setup utility yet. Sorry. Try running the game from DOS.

    Q: I want more levels!
    A: Take a look at the following adress:
       http://www.dtek.chalmers.se/~d98peitz/happy
       Any new levels can be found there.       

    Q: How can I climb the vines?
    A: You can't. It's only scenery.


AUTHORS & CONTACT

    Happyland Adventures is written by Johan Peitz. Graphics are created
    by Ari Feldman.

    If you have comments, bug reports, or just want to ask something
    you can contact me by e-mail.

      E-Mail: d98peitz@dtek.chalmers.se

    You can also visit me on the web.

      http://www.dtek.chalmers.se/~d98peitz/


SPECIAL THANKS

    I would like to thank the following people:

    Ari Feldman for Spritelib
    DJ Delorie for DJGPP
    Shawn Hargreavers for Allegro
    Ivan Baldo for PPCOL
    Robert H�hne for RHIDE


EXTRAS

    My SpriteLib license number is: 129.16.30.119-952518357



                                - The End-

