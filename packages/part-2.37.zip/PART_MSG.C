#include "part.h"

     /* VERSION_DATE "2.37.05            June 10, 1998" */
#define VERSION_DATE "2.37.12            Oct  18, 1998"
#define VERSION      "2.37.12"

#define HOME_URL "http://www.users.intercom.com/~ranish/part/"


#ifdef LANG_de		/* German  */
  #define de(x)	x;
#else
  #define de(x)
#endif

#ifdef LANG_ru		/* Russian */
  #define ru(x)	x;
#else
  #define ru(x)
#endif

#ifdef LANG_se		/* Swedish */
  #define se(x)	x;
#else
  #define se(x)
#endif

#ifdef LANG_sp		/* Spanish */
  #define sp(x)	x;
#else
  #define sp(x)
#endif

#ifdef LANG_fr		/* French */
  #define fr(x)	x;
#else
  #define fr(x)
#endif

#ifdef LANG_it		/* Italian */
  #define it(x)	x;
#else
  #define it(x)
#endif

#ifdef LANG_nl          /* Dutch   */
  #define nl(x) x;
#else
  #define nl(x)
#endif

#ifdef LANG_cs          /* Czech   */
  #define cs(x) x;
#else
  #define cs(x)
#endif

#if !defined(LANG_de) && !defined(LANG_ru) && !defined(LANG_se) && \
    !defined(LANG_sp) && !defined(LANG_fr) && !defined(LANG_it) && \
    !defined(LANG_nl) && !defined(LANG_cs)
  #define en(x)	x;
#else
  #define en(x)
#endif

void set_messages(void)
{
 int i;

en( PROGRAM_TITLE = "Ranish Partition Manager          Version "VERSION_DATE)
se( PROGRAM_TITLE = "Ranish Partion program            Version "VERSION_DATE)
sp( PROGRAM_TITLE = "Ranish Director de Partici�n      Versi�n "VERSION_DATE)
de( PROGRAM_TITLE = "Ranish Partition Manager          Version "VERSION_DATE)
ru( PROGRAM_TITLE = "Ranish Partition Manager           ����� "VERSION_DATE)
fr( PROGRAM_TITLE = "Ranish Partition Manager          Version "VERSION_DATE)
it( PROGRAM_TITLE = "Ranish Partition Manager         Versione "VERSION_DATE)
nl( PROGRAM_TITLE = "Ranish Partition Manager           Versie "VERSION_DATE)
cs( PROGRAM_TITLE = "Ranish Partition Manager            Verze "VERSION_DATE)

en( MANAGER_TITLE = "Advanced Boot Manager v"VERSION"")
se( MANAGER_TITLE = "Advanced Boot Manager v"VERSION"")
sp( MANAGER_TITLE = "Avansado Boot Manager v"VERSION"")
de( MANAGER_TITLE = "Advanced Boot Manager v"VERSION"")
ru( MANAGER_TITLE = "Advanced Boot Manager v"VERSION"")
fr( MANAGER_TITLE = "Advanced Boot Manager v"VERSION"")
it( MANAGER_TITLE = "Boot Manager Avanzato v"VERSION"")
nl( MANAGER_TITLE = "Advanced Boot Manager v"VERSION"")
cs( MANAGER_TITLE = "Advanced Boot Manager v"VERSION"")

en( HEADER_GET  = "Hard Disk ..    Getting hard disk parameters ...")
se( HEADER_GET  = "H�rd Disk ..    L�ser h�rd disk parametrar ...")
sp( HEADER_GET  = "Disco Duro..    Adquiriedo Disco Duro par�metros ...")
de( HEADER_GET  = "Festplatte..    Ermittle Plattenparameter ...")
ru( HEADER_GET  = "������� ..    ����訢�� ��ࠬ���� ��᪠ ...")
fr( HEADER_GET  = "Disque Dur..    Recherche des param�tres ...")
it( HEADER_GET  = "Disco rig...    Acquisizione parametri disco ...")
nl( HEADER_GET  = "Harde sch...    Ophalen van vaste schijf parameters ...")
cs( HEADER_GET  = "Pevn� disk..    Z�sk�v�n� parametr� disku ...")

en( HEADER_EMBR = "EMBR Level..  ..... Mbytes")
se( HEADER_EMBR = "EMBR Level..  ..... Mbytes")
sp( HEADER_EMBR = "EMBR Nivel..  ..... Mbytes")
de( HEADER_EMBR = "EMBR Stufe..  ..... Mbytes")
ru( HEADER_EMBR = "EMBR Level..  ..... �����")
fr( HEADER_EMBR = "EMBR Niv  ..  ..... Moctet")
it( HEADER_EMBR = "EMBR Level..  ..... Mbytes")
nl( HEADER_EMBR = "EMBR Level..  ..... Mbyte ")
cs( HEADER_EMBR = "�rove� EMBR.  ..... MByt� ")

en( HEADER_CHS  = "Hard Disk ..  ..... Mbytes  [ .... cylinders  x ... heads  x ... sectors ]")
se( HEADER_CHS  = "H�rd Disk ..  ..... Mbytes  [ .... cylinders  x ... heads  x ... sectors ]")
sp( HEADER_CHS  = "Disco Duro..  ..... Mbytes  [ .... cilindros  x ... lados  x ... sectores]")
de( HEADER_CHS  = "Festplatte..  ..... Mbytes  [ .... Zylinder   x ... K�pfe  x ... Sektoren]")
ru( HEADER_CHS  = "������� ..  ..... �����   [ ....  樫����  x ... ��஭ x ... ᥪ�� ]")
fr( HEADER_CHS  = "Disque Dur..  ..... Moctet  [ .... Cylindres  x ... t�tes  x ... secteurs]")
it( HEADER_CHS  = "Disco rig...  ..... Mbytes  [ ....  cilindri  x ...  test  x ... settori ]")
nl( HEADER_CHS  = "Vaste sch...  ..... Mbyte   [ .... cylinders  x ... koppen x ... sectoren]")
cs( HEADER_CHS  = "Pevn� disk..  ..... MByt�   [ .... cylindr�   x ... hlav   x ... sektor� ]")

en( HEADER_CHS2 = "                  File               Starting        Ending      Partition")
se( HEADER_CHS2 = "                  Fil                Startar         Slutar      Partition")
sp( HEADER_CHS2 = "                 Archivo            Comenzando     Finalizando   Partici�n")
de( HEADER_CHS2 = "                 Datei-              Start            Ende      Partitions")
ru( HEADER_CHS2 = "                  ���                ����         ��᫥����       ���� ")
fr( HEADER_CHS2 = "             Type de syst�me          D�but           Fin       Taille[Ko]")
it( HEADER_CHS2 = "                  File               Inizio           Fine      Partizione")
nl( HEADER_CHS2 = "              Type bestands-          Begin           Eind        Partitie")
cs( HEADER_CHS2 = "           Typ souborov�ho          Po��te�n�       Koncov�      Velikost ")

en( HEADER_CHS3 = "#  Active      System Type        Cyl Side Sect   Cyl Side Sect  Size [KB]")
se( HEADER_CHS3 = "#  Aktiv       System Typ         Cyl Sida Sekt   Cyl Sida Sekt  Strlk [K]")
sp( HEADER_CHS3 = "#  Activo    Tipo de Sistema      Cil Lado Secc   Cil Lado Secc  tama�o[K]")
de( HEADER_CHS3 = "# Startbar     system Typ         Zyl Kopf Sekt   Zyl Kopf Sekt  Gr��e[KB]")
ru( HEADER_CHS3 = "# ����騩   �������� ���⥬�      ��� ��� ����   ��� ��� ����    ࠧ����")
fr( HEADER_CHS3 = "#  Active      de fichier         Cyl Face Sect   Cyl Face Sect  partition")
it( HEADER_CHS3 = "#  Attivo    Tipo di Sistema      Cil Lato Sett   Cil Lato Sett  Dim.  [K]")
nl( HEADER_CHS3 = "#  Actief       systeem           Cyl Kop  Sect   Cyl Kop  Sect  Omvang[K]")
cs( HEADER_CHS3 = "# Aktivn�       syst�mu          cyl hlava sekt  cyl hlava sekt  obl. [KB]")

              /*  "1   Yes  123456789_123456789_123 9999 9999 9999  9999 9999 9999 11,111,111"  */


en( HEADER_LBA  = "Hard Disk ..  ..... Mbytes  [ Base 11,111,111  Total 11,111,111  sectors ]")
se( HEADER_LBA  = "H�rd Disk ..  ..... Mbytes  [ Base 11,111,111  Total 11,111,111  sectors ]")
sp( HEADER_LBA  = "Disco Duro..  ..... Mbytes  [ Base 11,111,111  Total 11,111,111 sectores ]")
de( HEADER_LBA  = "Festplatte..  ..... Mbytes  [Start 11,111,111  Total 11,111,111 Sektoren ]")
ru( HEADER_LBA  = "������� ..  ..... �����   [ ���� 11,111,111  �ᥣ� 11,111,111 ᥪ�஢ ]")
fr( HEADER_LBA  = "Disque Dur..  ..... Moctet  [ Base 11,111,111  Total 11,111,111 secteurs ]")
it( HEADER_LBA  = "Disco rig...  ..... Mbytes  [ Base 11,111,111 Totale 11,111,111 settori  ]")
nl( HEADER_LBA  = "Vaste sch...  ..... Mbyte   [ Base 11,111,111 Totaal 11,111,111 sectoren ]")
cs( HEADER_LBA  = "Pevn� disk..  ..... MByt�   [Z�kl. 11,111,111  Celk. 11,111,111 sektor�  ]")

en( HEADER_LBA2 = "                  File           Starting  Number of     Ending  Partition")
se( HEADER_LBA2 = "                  Fil             Startar      Antal     Slutar  Partition")
sp( HEADER_LBA2 = "                 Archivo       Comenzando  N�mero de Finalizando Partici�n")
de( HEADER_LBA2 = "                 Datei-           Start    Anzahl der    Ende   Partitions")
ru( HEADER_LBA2 = "                  ���              ���� ������⢮  ��᫥����     ���� ")
fr( HEADER_LBA2 = "             Type de syst�me      D�but    Nombre de     Fin    Taille[Ko]")
it( HEADER_LBA2 = "                  File            Inizio   Numero di     Fine   Partizione")
nl( HEADER_LBA2 = "              Type bestands-       Begin    Aantal       Eind     Partitie")  
cs( HEADER_LBA2 = "            Typ souborov�ho     Po��te�n�      Po�et    Koncov�   Velikost")

en( HEADER_LBA3 = "#  Active      System Type         sector    sectors     sector  Size [KB]")
se( HEADER_LBA3 = "#  Aktiv       System Typ          sektor   sektorer     sektor  Strlk [K]")
sp( HEADER_LBA3 = "#  Activo    Tipo de Sistema       sector   sectores     sector  Tama�o[K]")
de( HEADER_LBA3 = "# Startbar     system Typ          Sektor   Sektoren     Sektor  Gr��e[KB]")
ru( HEADER_LBA3 = "# ����騩   �������� ���⥬�       ᥪ��   ᥪ�஢     ᥪ��    ࠧ����")
fr( HEADER_LBA3 = "#  Active      de fichier         secteur   secteurs    secteur  partition")
it( HEADER_LBA3 = "#  Attivo    Tipo di Sistema      settore   settori      settor  Dim.  [K]")
nl( HEADER_LBA3 = "#  Actief       systeem            sector   sectoren     sector  Omvang[K]")
cs( HEADER_LBA3 = "# Aktivn�        syst�mu           sektor    sektor�     sektor  obl. [KB]")

              /*  "1   Yes  123456789_123456789_123123456789 1234567890 1234567890 11,111,111"  */


                /*  Hard Disk 1  12345 MB  [ 1023 cyl x 255 heads x 63 sects = 11,111,111 sects ] */
en( HEADER_CMD = "  Hard Disk %d  %5lu MB  [ %4d cyl x %3d heads x %2d sects = %s sects ]\n\n")
se( HEADER_CMD = "H�rd Disk %d  %5lu MB  [ %4d cyl x %3d huvuden x %2d sekts = %s sekts ]\n\n")
sp( HEADER_CMD = " Disco Duro %d  %5lu MB  [ %4d cil x %3d lados x %2d sects = %s sects ]\n\n")
de( HEADER_CMD = " Festplatte %d  %5lu MB  [ %4d Zyl x %3d K�pfe x %2d Sekt. = %s Sekt. ]\n\n")
ru( HEADER_CMD = "  ������� %d  %5lu ��  [ %4d ��� x %3d ��� x %2d ���� = %s ���� ]\n\n")
fr( HEADER_CMD = " Disque Dur %d  %5lu Mo  [ %4d cyl x %3d t�tes x %2d sect = %s sect ]\n\n")
it( HEADER_CMD = "Disco rigido %d  %5lu MB  [ %4d cil x %3d testine x %2d sett = %s sett ]\n\n")
nl( HEADER_CMD = "Vast schijf %d  %5lu MB  [ %4d cyl x %3d koppen x %2d sect = %s sect  ]\n\n")
cs( HEADER_CMD = " Pevn� disk %d  %5lu MB  [ %4d cyl x %3d hlav  x %2d sekt. = %s sekt. ]\n\n")

en( HEADER_SYSTYPE = "  ID     File System Type          Setup  Format  PrintInfo")
se( HEADER_SYSTYPE = "  ID     Fil System Typ          Upps�tt  Format  SkrivInfo")
sp( HEADER_SYSTYPE = "  ID   Archivo Sistema Tipo     Organizar Formatear ImprimirInf")
de( HEADER_SYSTYPE = "  ID     Dateisystem Typ           Setup  Format  ZeigeInfo")
ru( HEADER_SYSTYPE = "  ID   ��� 䠩����� ��⥬�  ���䨣���� ��ଠ� ���ଠ��")
fr( HEADER_SYSTYPE = "  ID   Type syst�me fichier       Config  Format  Impr.Info")
it( HEADER_SYSTYPE = "  ID     File Sistema Tipo  Impostazioni Formattare StampaInfo")
nl( HEADER_SYSTYPE = "  ID   Bestandssysteem type  Configureren  Formatteren  Info")
cs( HEADER_SYSTYPE = "  ID     Typ datov�ho syst�mu      Nastav Form�t  Uka� info")

en( HEADER_BOOT_MENU = "  # Dev Partitions PP  Name                       Keys")
se( HEADER_BOOT_MENU = "  # Dev Partitions PP  Namn                  Tangenter")
sp( HEADER_BOOT_MENU = "  # Dev Particiones PC Nombre                   Llaves")
de( HEADER_BOOT_MENU = "  # Dev Partitions PP  Name                      Tast.")
ru( HEADER_BOOT_MENU = "  # Dev Partitions PP  Name                       Keys")
fr( HEADER_BOOT_MENU = "  # Dev Partitions PP  Nom                     Touches")
it( HEADER_BOOT_MENU = "  # Dev Partizioni PC  Numero                    Tasti")
nl( HEADER_BOOT_MENU = "  # Sta Partitie   PP  Beschrijving            Toetsen")
cs( HEADER_BOOT_MENU = "  # za� Oblast     PP  Jm�no                     Kl�v.")

en( MENU_HIDE     = " - Hide partition")
se( MENU_HIDE     = " - D�lj partition")
sp( MENU_HIDE     = " - Esconder Partici�n")
de( MENU_HIDE     = " - Verstecke Partition")
ru( MENU_HIDE     = " - ������� ࠧ���")
fr( MENU_HIDE     = " - Cacher partition")
it( MENU_HIDE     = " - Nascondere Partizione")
nl( MENU_HIDE     = " - Partitie verbergen")
cs( MENU_HIDE     = " - Skryt� oblasti")

en( MENU_FORMAT   = " - Format partition")
se( MENU_FORMAT   = " - Formatera partition")
sp( MENU_FORMAT   = " - Formatear Partici�n")
de( MENU_FORMAT   = " - Formatiere Partition")
ru( MENU_FORMAT   = " - ���ଠ�஢��� ࠧ���")
fr( MENU_FORMAT   = " - Formatter partition")
it( MENU_FORMAT   = " - Formattare Partizione")
nl( MENU_FORMAT   = " - Partitie formatteren")
cs( MENU_FORMAT   = " - Form�tov�n� oblasti")

en( MENU_VERIFY   = " - Verify disk surface")
se( MENU_VERIFY   = " - Verifiera disk yta")
sp( MENU_VERIFY   = " - Verificar Cara de Disco")
de( MENU_VERIFY   = " - Oberfl�chentest")
ru( MENU_VERIFY   = " - ���䨪��� �����孮��")
fr( MENU_VERIFY   = " - V�rifier partition")
it( MENU_VERIFY   = " - Verifica superficie del disco")
nl( MENU_VERIFY   = " - Oppervlaktecontrole")
cs( MENU_VERIFY   = " - Test povrchu")

en( MENU_PREVIEW  = " - Preview partition table")
se( MENU_PREVIEW  = " - Titta p� partitions tabell")
sp( MENU_PREVIEW  = " - Partici�n Tabla Previa")
de( MENU_PREVIEW  = " - Partitionstabelle anzeigen")
ru( MENU_PREVIEW  = " - ��ᬮ�� ⠡���� ࠧ�����")
fr( MENU_PREVIEW  = " - Voir table de partitions")
it( MENU_PREVIEW  = " - Anteprima tabella partizione")
nl( MENU_PREVIEW  = " - Partitietabel bekijken")
cs( MENU_PREVIEW  = " - Zobrazen� tabulky oblast�")

en( MENU_INST_IPL = " - Load custom IPL")
se( MENU_INST_IPL = " - Ladda egen IPL")
sp( MENU_INST_IPL = " - Cargar adaptado IPL")
de( MENU_INST_IPL = " - Lade eigenen IPL")
ru( MENU_INST_IPL = " - ��⠭����� ᢮� IPL")
fr( MENU_INST_IPL = " - Charger IPL perso")
it( MENU_INST_IPL = " - Caricare IPL personale")
nl( MENU_INST_IPL = " - Eigen IPL laden")
cs( MENU_INST_IPL = " - Zaveden� u�ivatelsk�ho IPL")

en( MENU_SAVE_MBR = " - Save MBR to file")
se( MENU_SAVE_MBR = " - Spara MBR till en fil")
sp( MENU_SAVE_MBR = " - Salvar MBR en un Archivo")
de( MENU_SAVE_MBR = " - Speichere MBR in Datei")
ru( MENU_SAVE_MBR = " - ���࠭��� MBR � 䠩�")
fr( MENU_SAVE_MBR = " - Sauver MBR dans un fichier")
it( MENU_SAVE_MBR = " - Salva MBR su file")
nl( MENU_SAVE_MBR = " - MBR naar bestand opslaan")
cs( MENU_SAVE_MBR = " - �schova MBR do souboru")

en( MENU_LOAD_MBR = " - Load MBR from file")
se( MENU_LOAD_MBR = " - Ladda MBR fr�n en fil")
sp( MENU_LOAD_MBR = " - Cargar MBR desde Archivo")
de( MENU_LOAD_MBR = " - Lade MBR aus Datei")
ru( MENU_LOAD_MBR = " - ����㧨�� MBR �� 䠩��")
fr( MENU_LOAD_MBR = " - Charger MBR d'un fichier")
it( MENU_LOAD_MBR = " - Carica MBR da file")
nl( MENU_LOAD_MBR = " - MBR uit bestand laden")
cs( MENU_LOAD_MBR = " - Obnova MBR ze souboru")

en( MENU_ADV_UNINST = " - Uninstall boot manager")
se( MENU_ADV_UNINST = " - Avinstallera boot hanterare")
sp( MENU_ADV_UNINST = " - Desinstalar boot director")
de( MENU_ADV_UNINST = " - Boot Manager deinstallieren")
ru( MENU_ADV_UNINST = " - ������� ��� �����稪")
fr( MENU_ADV_UNINST = " - D�sinstaller le boot manager")
it( MENU_ADV_UNINST = " - Disinstalla Boot Manager")
nl( MENU_ADV_UNINST = " - Boot manager de-installeren")
cs( MENU_ADV_UNINST = " - Odinstalov�n� Boot Manageru")

en( MENU_INSTALL   = " - Install compact boot manager, or A - Advanced")
se( MENU_INSTALL   = " - Installera IPL boot hanterare el A - Avancerad")
sp( MENU_INSTALL   = " - Instalar boot Director compacto, A - Avansado")
de( MENU_INSTALL   = " - Installiere Boot Manager,  oder  A - Advanced")
ru( MENU_INSTALL   = " - ��⠭����� �������� �����稪, . - Advanced")
fr( MENU_INSTALL   = " - Installer boot manager compact / A - Avanc�")
it( MENU_INSTALL   = " - Installare BootManager compatto, A - Avanzato")
nl( MENU_INSTALL   = " - Boot manager installeren    /    A - Geavanceerd")
cs( MENU_INSTALL   = " - Instalace Boot Manageru,   nebo  A - roz��en�ho")

en( MENU_UNINSTALL = " - Uninstall boot manager by loading standard IPL")
se( MENU_UNINSTALL = " - Avinstallera genom att installera en standard IPL")
sp( MENU_UNINSTALL = " - Desinstalar boot Director para montar normal IPL")
de( MENU_UNINSTALL = " - Deinstalliere Boot Manager durch Standard IPL")
ru( MENU_UNINSTALL = " - ������� �����稪, ��⠭���� �⠤���� DOS IPL")
fr( MENU_UNINSTALL = " - Remplacer le boot manager par l'IPL standard")
it( MENU_UNINSTALL = " - Disintalla Boot Manager per caricare IPL standard")
nl( MENU_UNINSTALL = " - Bootmanager de-installeren door standaard IPL te laden")
cs( MENU_UNINSTALL = " - Odstran�n� Boot Manageru a zaps�n� standardn�ho IPL")

en( MENU_INST_EXT = " - Install a \"non bootable\" message into EMBR")
se( MENU_INST_EXT = " - Installera ett \"icke bootbar\" meddelande i EMBR")
sp( MENU_INST_EXT = " - Instalar un \"non bootable\" mensage dentro EMBR")
de( MENU_INST_EXT = " - Installiere eine \"kein System\" Meldung im EMBR")
ru( MENU_INST_EXT = " - ��⠭����� ������� \"non bootable\" � EMBR")
fr( MENU_INST_EXT = " - Installer un message \"non bootable\" dans l'EMBR")
it( MENU_INST_EXT = " - Installare un \"non bootable\" messaggio nel EMBR")
nl( MENU_INST_EXT = " - Een \"non bootable\" bericht in de EMBR installeren")
cs( MENU_INST_EXT = " - Instalov�n� zpr�vy \"zde nen� syst�m\" do EMBR")

en( MENU_MAKE_PRI = " - Read help on how to make logical drive bootable")
se( MENU_MAKE_PRI = " - L�s hj�lpen hur man g�r en logisk drive bootbar")
sp( MENU_MAKE_PRI = " - Leer ayuda sobre como hacer la l�gica unidad bootable")
de( MENU_MAKE_PRI = " - Von Logischer Platte booten? - Siehe Hilfetext")
ru( MENU_MAKE_PRI = " - ������ � ⮬ ��� ᤥ���� ��� ࠧ��� ����㧮��")
fr( MENU_MAKE_PRI = " - Lire l'aide pour rendre un disque logique bootable")
it( MENU_MAKE_PRI = " - Leggere l'aiuto per rendere un disco logico bootstrappabile")
nl( MENU_MAKE_PRI = " - Lees help over hoe een station bootable te maken")
cs( MENU_MAKE_PRI = " - N�pov�da k zav�d�n� z logick�ho za��zen�")


en( ERROR_MALLOC    = "Cannot allocate more memory.")
se( ERROR_MALLOC    = "Kunde inte allokera minne med malloc.")
sp( ERROR_MALLOC    = "No pudo asignar mas memoria.")
de( ERROR_MALLOC    = "Nicht gen�gend Speicher.")
ru( ERROR_MALLOC    = "�������筮 �����.")
fr( ERROR_MALLOC    = "Impossible d'allouer plus de m�moire.")
it( ERROR_MALLOC    = "Impossibile assegnare piu' memoria.")
nl( ERROR_MALLOC    = "Er is onvoldoende geheugen beschikbaar.")
cs( ERROR_MALLOC    = "M�lo pam�ti.")

en( ERROR_DISK_INFO = "Error getting hard disk parameters.")
se( ERROR_DISK_INFO = "Fel vid l�sning av h�rd disk parametrar.")
sp( ERROR_DISK_INFO = "Error consiguiendo par�metros del disco duro.")
de( ERROR_DISK_INFO = "Fehler beim Zugiff auf Festplatte.")
ru( ERROR_DISK_INFO = "�訡�� �� �⥭�� ��ࠬ��஢ ��᪠.")
fr( ERROR_DISK_INFO = "Impossible d'obtenir les param�tres du disque dur.")
it( ERROR_DISK_INFO = "Errore nel ricavare i parametri del disco.")
nl( ERROR_DISK_INFO = "Fout tijdens ophalen van vaste schijf parameters.")
cs( ERROR_DISK_INFO = "Chyba p�i p��stupu na disk.")

en( ERROR_FIX_FIRST = "You should correct errors first.")
se( ERROR_FIX_FIRST = "Du borde fixa partitions fel f�rst.")
sp( ERROR_FIX_FIRST = "Debe corregir errores primero.")
de( ERROR_FIX_FIRST = "Bitte zuerst Fehler korrigieren.")
ru( ERROR_FIX_FIRST = "���砫� ����室��� ��ࠢ��� �訡��.")
fr( ERROR_FIX_FIRST = "Corrigez d'abord les erreurs.")
it( ERROR_FIX_FIRST = "Correggere gli errori prima di continuare.")
nl( ERROR_FIX_FIRST = "U moet eerst de fouten corrigeren.")
cs( ERROR_FIX_FIRST = "Nap�ed pros�m odstra�e chybu.")

en( ERROR_INH_INVAL = "You cannot save object if one of its parents is invalid or is not saved.")
se( ERROR_INH_INVAL = "Du kan inte spara objektet om en av dens f�r�ldrar �r ogiltig eller inte sparad.")
sp( ERROR_INH_INVAL = "No puede salvar objeto si uno de sus parientes es inv�lido o no es salvado.")
de( ERROR_INH_INVAL = "Ein �bergeordnetes Element ist (noch) ung�ltig - kann nicht speichern.")
ru( ERROR_INH_INVAL = "�� ���� ��࠭��� - ���� �� த�⥫�� �� ��࠭�� ��� ᮤ�ন� �訡��.")
fr( ERROR_INH_INVAL = "Impossible de sauver l'objet, un de ses parents est invalide ou non sauv�.")
it( ERROR_INH_INVAL = "Non e' possibile salvare oggetti se uno dei suoi collegati non e' valido o non salvato.")
nl( ERROR_INH_INVAL = "Een object kan niet opgeslagen worden, als het bovenliggende object ongeldig is.")
cs( ERROR_INH_INVAL = "Nelze ulo�it, proto�e nad��zen� objekt je vadn� nebo nen� dosud uschov�n.")

en( ERROR_READ_MBR  = "Error reading MBR from disk.")
se( ERROR_READ_MBR  = "Fel vid l�sning av MBR fr�n disk.")
sp( ERROR_READ_MBR  = "Error leyendo MBR del disco.")
de( ERROR_READ_MBR  = "Fehler beim Lesen des MBR.")
ru( ERROR_READ_MBR  = "�訡�� �� �⥭�� MBR � ��᪠.")
fr( ERROR_READ_MBR  = "Erreur de lecture du MBR du disque.")
it( ERROR_READ_MBR  = "Errore nella lettura del MBR dal disco.")
nl( ERROR_READ_MBR  = "Fout tijdens het lezen van de MBR.")
cs( ERROR_READ_MBR  = "Chyba p�i �ten� MBR.")

en( ERROR_SAVE_MBR  = "Error writing MBR to disk.")
se( ERROR_SAVE_MBR  = "Fel vid skrivning av MBR till disk.")
sp( ERROR_SAVE_MBR  = "Error escribiendo MBR al disco.")
de( ERROR_SAVE_MBR  = "Fehler beim Schreiben des MBR.")
ru( ERROR_SAVE_MBR  = "�訡�� ����� MBR �� ���.")
fr( ERROR_SAVE_MBR  = "Erreur d'�criture du MBR du disque.")
it( ERROR_SAVE_MBR  = "Errore nella scrittura del MBR sul disco.")
nl( ERROR_SAVE_MBR  = "Fout tijdens het schrijven van de MBR.")
cs( ERROR_SAVE_MBR  = "Chyba p�i z�pisu MBR.")

en( ERROR_READ_ADV  = "Error reading Advanced MBR from disk.")
se( ERROR_READ_ADV  = "Fel vid l�sning av Avancerad MBR fr�n disk.")
sp( ERROR_READ_ADV  = "Error leyendo Avansado MBR desde disco.")
de( ERROR_READ_ADV  = "Lesefehler beim Advanced MBR.")
ru( ERROR_READ_ADV  = "�訡�� �� �⥭�� Advanced MBR � ��᪠.")
fr( ERROR_READ_ADV  = "Erreur de lecture du MBR Avanc� du disque.")
it( ERROR_READ_ADV  = "Errore nella lettura del MBR Avanzato dal disco.")
nl( ERROR_READ_ADV  = "Fout bij het lezen van de geavanceerde MBR.")
cs( ERROR_READ_ADV  = "Chyba p�i �ten� roz��en�ho MBR.")

en( ERROR_SAVE_ADV  = "Error writing Advanced MBR to disk.")
se( ERROR_SAVE_ADV  = "Fel vid skrivning av Avancerad MBR till disk.")
sp( ERROR_SAVE_ADV  = "Error escribiendo Avansado MBR al diso.")
de( ERROR_SAVE_ADV  = "Schreibfehler beim Advanced MBR.")
ru( ERROR_SAVE_ADV  = "�訡�� ����� Advanced MBR �� ���.")
fr( ERROR_SAVE_ADV  = "Erreur d'�criture du MBR Avanc� du disque.")
it( ERROR_SAVE_ADV  = "Errore nella scrittura del MBR Avanzato sul disco.")
nl( ERROR_SAVE_ADV  = "Fout bij het schrijven van de geavanceerde MBR.")
cs( ERROR_SAVE_ADV  = "Chyba p�i z�pisu roz��en�ho MBR.")

en( ERROR_LOAD_FILE = "Error reading from file.")
se( ERROR_LOAD_FILE = "Fel vid l�sning fr�n fil.")
sp( ERROR_LOAD_FILE = "Error leyendo desde archivo.")
de( ERROR_LOAD_FILE = "Fehler beim Lesen der Datei.")
ru( ERROR_LOAD_FILE = "�訡�� �� �⥭�� �� 䠩��.")
fr( ERROR_LOAD_FILE = "Erreur de lecture d'un fichier.")
it( ERROR_LOAD_FILE = "Errore nella lettura da file.")
nl( ERROR_LOAD_FILE = "Fout bij het lezen van het bestand.")
cs( ERROR_LOAD_FILE = "Chyba p�i �ten� souboru.")

en( ERROR_SAVE_FILE = "Error writing to file.")
se( ERROR_SAVE_FILE = "Fel vid skrivning till fil.")
sp( ERROR_SAVE_FILE = "Error escribiendo al archivo.")
de( ERROR_SAVE_FILE = "Fehler beim Schreiben in Datei.")
ru( ERROR_SAVE_FILE = "�訡�� �� ����� � 䠩�.")
fr( ERROR_SAVE_FILE = "Erreur d'�criture d'un fichier.")
it( ERROR_SAVE_FILE = "Errore nella scrittura su file.")
nl( ERROR_SAVE_FILE = "Fout bij het schrijven naar het bestand.")
cs( ERROR_SAVE_FILE = "Chyba p�i z�pisu souboru.")

en( WARN_INVALID    = "Some records in the partition table are invalid.")
se( WARN_INVALID    = "En eller flera poster i partitions tabellen �r ogiltiga.")
sp( WARN_INVALID    = "Alg�nos records en la tabla de partici�n son invalidos.")
de( WARN_INVALID    = "Einige Eintr�ge in der Tabelle sind ung�ltig.")
ru( WARN_INVALID    = "��ࠬ���� ������ ��� ����� ࠧ����� �訡���.")
fr( WARN_INVALID    = "Des zones de la table de partition sont invalides.")
it( WARN_INVALID    = "Alcuni records nella tabella delle partizioni non sono validi.")
nl( WARN_INVALID    = "Sommige records in de partitie tabel zijn ongeldig.")
cs( WARN_INVALID    = "N�kter� �daje v tabulce oblast� jsou neplatn�.")

en( MESG_BIOS_CYL   = "Note that BIOS reports only %d cylinders.")
se( MESG_BIOS_CYL   = "Note that BIOS reports only %d cylinders.")
sp( MESG_BIOS_CYL   = "Recuerde que BIOS reporta unicamente %d cylindros.")
de( MESG_BIOS_CYL   = "Achtung! Das BIOS meldet nur %d Zylinder.")
ru( MESG_BIOS_CYL   = "���� �� BIOS �����뢠�� ⮫쪮 %d 樫����.")
fr( MESG_BIOS_CYL   = "Note: le BIOS ne reporte que %d cylindres.")
it( MESG_BIOS_CYL   = "Attenzione: il BIOS riporta solo %d cilindri.")
nl( MESG_BIOS_CYL   = "Let erop dat het BIOS slechts %d cylinders ondersteunt.")
cs( MESG_BIOS_CYL   = "Pozor! BIOS ozn�mil pouze %d cylindr�.")

en( ERROR_ADV_NOSPACE = "You don't have enough free space to install Boot Manager")
se( ERROR_ADV_NOSPACE = "Du har inte tillr�ckligt med ledigt diskutrymme f�r att installera BtMgr")
sp( ERROR_ADV_NOSPACE = "No hay suficiente espacio para instalar Boot Manager")
de( ERROR_ADV_NOSPACE = "Nicht gen�gend Platz f�r den Boot Manager vorhanden.")
ru( ERROR_ADV_NOSPACE = "�������筮 ᢮������� ���� �⮡� ��⠭����� �����稪")
fr( ERROR_ADV_NOSPACE = "Pas assez d'espace disque libre pour installer Boot Manager")
it( ERROR_ADV_NOSPACE = "Non c'e' spazio sufficiente per installare Boot Manager.")
nl( ERROR_ADV_NOSPACE = "Niet genoeg vrije ruimte om Boot Manager te installeren.")
cs( ERROR_ADV_NOSPACE = "Nen� dostatek prostoru pro instalaci Boot Manageru.")

en( ERROR_NO_ADV    = "You must have Boot Manager partition of sufficient size.")
se( ERROR_NO_ADV    = "Du m�ste ha en partition till boot hanteraren av tillr�cklig storlek.")
sp( ERROR_NO_ADV    = "Usted debe tenere Boot Manager partici�n de suficiente medida.")
de( ERROR_NO_ADV    = "Die Boot Manager Partition ist nicht gro� genug.")
ru( ERROR_NO_ADV    = "��������� �����筮 ����让 ࠧ��� ��� Boot Manager")
fr( ERROR_NO_ADV    = "La partition de Boot Manager n'est pas assez grande.")
it( ERROR_NO_ADV    = "Si deve avere la partizione di Boot Manager di dimensioni sufficienti.")
nl( ERROR_NO_ADV    = "De Boot Manager partitie is niet groot genoeg.")
cs( ERROR_NO_ADV    = "Oblast pro Boot Manager je p��li� mal�.")

en( ERROR_ADV_BAD   = "Advanced MBR doesn't have valid signature.")
se( ERROR_ADV_BAD   = "Avancerade MBR har inte en giltig signatur.")
sp( ERROR_ADV_BAD   = "Advansado MBR no tiene firma v�lida.")
de( ERROR_ADV_BAD   = "Der Advanced MBR hat keine g�ltige Signatur.")
ru( ERROR_ADV_BAD   = "Advanced MBR doesn't have valid signature.")
fr( ERROR_ADV_BAD   = "Le MBR Avanc� a une signature invalide.")
it( ERROR_ADV_BAD   = "L'MBR Avanzato non � valido.")
nl( ERROR_ADV_BAD   = "De geavanceerde MBR is niet geldig.")
cs( ERROR_ADV_BAD   = "Roz��en� MBR nem� platnou zna�ku.")

en( ERROR_ADV_VER   = "Warning! Advanced MBR has newer version than this program.")
se( ERROR_ADV_VER   = "Warning! Avancerade MBR har nyare version �n detta program.")
sp( ERROR_ADV_VER   = "Warning! Advansado MBR tiene una versi�n mas reciente.")
de( ERROR_ADV_VER   = "Achtung! Der Advanced MBR ist neuer als dieses Programm.")
ru( ERROR_ADV_VER   = "Warning! Advanced MBR �� ᮧ��� ����� ����� ���ᨥ� �⮩ �ணࠬ��")
fr( ERROR_ADV_VER   = "Attention! Le MBR Avanc� est plus r�cent que ce programme.")
it( ERROR_ADV_VER   = "L'MBR Avanzato attuale � pi� recente di questo programma.")
nl( ERROR_ADV_VER   = "Waarschuwing! De MBR heeft een nieuwere versie dan dit programma.")
cs( ERROR_ADV_VER   = "Pozor! Roz��en� MBR je nov�j� ne� tento program.")

en( ERROR_GR_FOUR   = "Cannot uninstall, because there are more than four partitions.")
se( ERROR_GR_FOUR   = "Kan ej avinstallera f�r att du har mer �n 4 partitioner.")
sp( ERROR_GR_FOUR   = "No puede desinstalar, porque hay mas de cuatros partici�nes.")
de( ERROR_GR_FOUR   = "Deinstallieren unm�glich - es sind mehr als vier Partitionen.")
ru( ERROR_GR_FOUR   = "� ��� ����� 祬 ���� ࠧ���� - ��� �� ������ � MBR.")
fr( ERROR_GR_FOUR   = "Impossible de d�sinstaller car il y a plus de 4 partitions.")
it( ERROR_GR_FOUR   = "Impossibile disinstallare: ci sono pi� di quattro partizioni.")
nl( ERROR_GR_FOUR   = "Onmogelijk te installeren, omdat er meer dan 4 partities zijn.")
cs( ERROR_GR_FOUR   = "Odinstalov�n� nen� mo�n�, proto�e je zde v�ce jak �ty�i oblasti.")

en( ERROR_NO_UNUSED = "Not enough unused entries in the partition table!")
se( ERROR_NO_UNUSED = "Inte nog med oanv�nda poster i partitions tabellen!")
sp( ERROR_NO_UNUSED = "No hay suficientes entradas libres en tabla de particion!")
de( ERROR_NO_UNUSED = "Nicht gen�gend freie Eintr�ge in der Tabelle!")
ru( ERROR_NO_UNUSED = "Not enough unused entries in the partition table!")
fr( ERROR_NO_UNUSED = "Pas assez d'entr�es libres dans la table de partition!")
it( ERROR_NO_UNUSED = "Non ci sono sufficienti entrate libere nella tabella delle partizioni!")
nl( ERROR_NO_UNUSED = "Niet genoeg ongebruikte ingangen in de partitie tabel!")
cs( ERROR_NO_UNUSED = "V tabulce oblast� nen� dostatek voln�ch z�znam�!")

en( ERR_BOOTREC = "   boot record")
se( ERR_BOOTREC = "   boot record")
sp( ERR_BOOTREC = "   boot record")
de( ERR_BOOTREC = "   boot record")
ru( ERR_BOOTREC = "   boot record")
fr( ERR_BOOTREC = "   boot record")
it( ERR_BOOTREC = "   boot record")
nl( ERR_BOOTREC = "   boot record")
cs( ERR_BOOTREC = "   zav�d�c� z�znam")

en( ERR_INCONS  = "  inconsistent")
se( ERR_INCONS  = "  inkonsistent")
sp( ERR_INCONS  = " inconsistente")
de( ERR_INCONS  = "  inkonsistent")
ru( ERR_INCONS  = "��ᮮ⢥��⢨�")
fr( ERR_INCONS  = "    incoh�rent")
it( ERR_INCONS  = " inconsistente")
nl( ERR_INCONS  = "  inconsistent")
cs( ERR_INCONS  = "nekonzistentn�")

en( ERR_OVERLAP = " overlapped")
se( ERR_OVERLAP = "�verlappande")
sp( ERR_OVERLAP = "    solapar")
de( ERR_OVERLAP = "�berlappend")
ru( ERR_OVERLAP = "����祭��")
fr( ERR_OVERLAP = "  superpos�")
it( ERR_OVERLAP = "sovrapposto")
nl( ERR_OVERLAP = "overlappend")
cs( ERR_OVERLAP = "p�ekr�vaj�c� se")

en( ERR_RANGE   = "   range")
se( ERR_RANGE   = "   range")
sp( ERR_RANGE   = "   rango")
de( ERR_RANGE   = " Bereich")
ru( ERR_RANGE   = " �࠭��")
fr( ERR_RANGE   = "   plage")
it( ERR_RANGE   = "interval")
nl( ERR_RANGE   = "  bereik")
cs( ERR_RANGE   = "  rozsah")

en( ERR_MBR     = "  mbr")
se( ERR_MBR     = "  mbr")
sp( ERR_MBR     = "  mbr")
de( ERR_MBR     = "  MBR")
ru( ERR_MBR     = "  mbr")
fr( ERR_MBR     = "  MBR")
it( ERR_MBR     = "  MBR")
nl( ERR_MBR     = "  MBR")
cs( ERR_MBR     = "  MBR")

en( HINT_ADV    = "Space - edit boot menu   Ins - select system type   Enter - setup")
se( HINT_ADV    = "Space - editera meny     Ins - v�lj system typ      Enter - Konfigurera")
sp( HINT_ADV    = "Space - editar men�      Ins - escoje tipo sistema  Enter - instalar")
de( HINT_ADV    = "Space - Menu bearbeiten  Ins - Systemtyp w�hlen     Enter - Setup")
ru( HINT_ADV    = "Space - ।���� ����    Ins - �롮� ⨯� ��⥬�   Enter - ���䨣.")
fr( HINT_ADV    = "Espace- editer menu boot Ins - choix syst. fichiers Entr�e- Config.")
it( HINT_ADV    = "Spazio - modifica menu   Ins - seleziona tipo sistema  Enter - Setup")
nl( HINT_ADV    = "Spatie - Menu bewerken   Ins - Systeem type sel.    Enter - Config.")
cs( HINT_ADV    = "<mezera> - nab�dka       <Ins> - volba soub. syst.  <Enter> - nastaven�")

en( HINT_INS    = "Space - toggle active    Ins - select system type   Enter - setup")
se( HINT_INS    = "Space - �ndra aktiv      Ins - v�lj system typ      Enter - Konfigurera")
sp( HINT_INS    = "Space - cambia activo    Ins - escoje tipo sistema  Enter - instalar")
de( HINT_INS    = "Space - Startbar ein/aus Ins - Systemtyp w�hlen     Enter - Setup")
ru( HINT_INS    = "Space - ����� ⥪�騩  Ins - �롮� ⨯� ��⥬�   Enter - ���䨣.")
fr( HINT_INS    = "Espace- active/inactive  Ins - choix syst. fichiers Entr�e- Config.")
it( HINT_INS    = "Spazio - cambia attivo   Ins - seleziona tipo sistema  Enter - Setup")
nl( HINT_INS    = "Spatie - Actief/inactief Ins - Systeem type sel.    Enter - Config.")
cs( HINT_INS    = "<mezera> - m�n� aktivn�  <Ins> - volba soub. syst.  <Enter> - nastaven�")

en( HINT_CHS    = "You can use + and - keys   Cyl=%lu..%lu  Side=0..%d  Sect=1..%d")
se( HINT_CHS    = "Du kan anv�nda + och -     Cyl=%lu..%lu  Sida=0..%d  Sekt=1..%d")
sp( HINT_CHS    = "Puede usar + y - teclas    Cyl=%lu..%lu  Side=0..%d  Sect=1..%d")
de( HINT_CHS    = "Mit den Tasten + und -     Zyl=%lu..%lu  Kopf=0..%d  Sekt=1..%d")
ru( HINT_CHS    = "����� �ᯮ�짮���� + � -   ���=%lu..%lu  ���=0..%d  ����=1..%d")
fr( HINT_CHS    = "Presser les touches + et -  Cyl=%lu..%lu  Face=0..%d  Sect=1..%d")
it( HINT_CHS    = "Usare tasti + e -          Cil=%lu..%lu  Test=0..%d  Sett=1..%d")
nl( HINT_CHS    = "Gebruik de + en - toetsen  Cyl=%lu..%lu  Kop=0..%d  Sect=1..%d")
cs( HINT_CHS    = "M��ete pou��t + a -       cyl=%lu..%lu  hlava=0..%d  sekt=1..%d")

en( HINT_LBA    = "You can use + and - keys   Starting=%lu..%lu   Sectors=1..%lu")
se( HINT_LBA    = "Du kan anv�nda + och -     Starting=%lu..%lu   Sektorer=1..%lu")
sp( HINT_LBA    = "Puede usar + y - teclas    Comenzando=%lu..%lu   Sectores=1..%lu")
de( HINT_LBA    = "Mit den Tasten + und -     Start=%lu..%lu   Sektoren=1..%lu")
ru( HINT_LBA    = "����� �ᯮ�짮���� + � -   ��砫�=%lu..%lu   ������⢮=1..%lu")
fr( HINT_LBA    = "Presser les touches + et -  D�but=%lu..%lu   Secteurs=1..%lu")
it( HINT_LBA    = "Usare tasti + e -          Inizio=%lu..%lu   Settori=1..%lu")
nl( HINT_LBA    = "Gebruik de + en - toetsen  Begin=%lu..%lu    Sectoren=1..%lu")
cs( HINT_LBA    = "M��ete pou��t + a -       po��te�n�=%lu..%lu   sektory=1..%lu")

en( HINT_RETURN = "    Press ESC to return from preview mode")
se( HINT_RETURN = "    Tryck ESC f�r att �terv�nda fr�n f�rhandsvisning")
sp( HINT_RETURN = "    Presione ESC para regresar al modo previo")
de( HINT_RETURN = "    ESC um den Anzeigemodus zu beenden")
ru( HINT_RETURN = "    ������ ESC ��� ������")
fr( HINT_RETURN = "    Presser Echap pour revenir au mode pr�c�dent")
it( HINT_RETURN = "    Premere ESC per uscire dall'anteprima")
nl( HINT_RETURN = "    Druk ESC om de preview-modus te beeindigen.") 
cs( HINT_RETURN = "    Stisknut�m <ESC> ukon��te zobrazen�")

en( MESG_MBR_SAVED  = "MBR was saved to hard disk.")
se( MESG_MBR_SAVED  = "MBR �r sparad till h�rd disk.")
sp( MESG_MBR_SAVED  = "MBR fue guardado en el disco duro.")
de( MESG_MBR_SAVED  = "MBR wurde geschrieben.")
ru( MESG_MBR_SAVED  = "MBR ��࠭� �� ���.")
fr( MESG_MBR_SAVED  = "MBR sauv� sur le disque dur.")
it( MESG_MBR_SAVED  = "L'MBR � stato salvato sul disco.")
nl( MESG_MBR_SAVED  = "MBR is opgeslagen.")
cs( MESG_MBR_SAVED  = "MBR byl zaps�n na disk.")

en( MESG_FILE_SAVED = "MBR was saved to file.")
se( MESG_FILE_SAVED = "MBR �r sparad till fil.")
sp( MESG_FILE_SAVED = "MBR fue guardado al archivo.")
de( MESG_FILE_SAVED = "MBR wurde gespeichert.")
ru( MESG_FILE_SAVED = "���� ��࠭� �� ���.")
fr( MESG_FILE_SAVED = "MBR sauv� dans un fichier.")
it( MESG_FILE_SAVED = "L'MBR � stato salvato su file.")
nl( MESG_FILE_SAVED = "MBR is naar bestand geschreven.")
cs( MESG_FILE_SAVED = "MBR byl uschov�n do souboru.")

en( MESG_FILE_LOADD = "New MBR data was loaded from file. Press F2 to save changes.")
se( MESG_FILE_LOADD = "Ny MBR data �r laddad fr�n fil. Tryck F2 f�r att spara �ndringen.")
sp( MESG_FILE_LOADD = "Nuevo MBR datos cargado del archivo. Presione F2 para guardar cambios.")
de( MESG_FILE_LOADD = "Neuer MBR wurde eingeladen. F2 um ihn zu schreiben.")
ru( MESG_FILE_LOADD = "���� MBR ����㦥� � ������. ������ F2 �⮡� ������� ���������.")
fr( MESG_FILE_LOADD = "Nouveau MBR charg� d'un fichier. Presser F2 pour enregister.")
it( MESG_FILE_LOADD = "I nuovi dati del MBR sono stati caricati dal file. Premere F2 per salvare le modifiche.")
nl( MESG_FILE_LOADD = "Nieuwe MBR is geladen. Druk op F2 om de veranderingen op te slaan.")
cs( MESG_FILE_LOADD = "Nov� MBR byl zaveden ze souboru. Stisknut�m <F2> jej zap��ete na disk.")

en( MESG_MBR_SAVED2 = "New MBR data was loaded from file.\nMBR was saved to hard disk.")
se( MESG_MBR_SAVED2 = "Ny MBR data �r laddad fr�n fil.\nMBR �r sparad till h�rd disk.")
sp( MESG_MBR_SAVED2 = "Nuevo MBR datos cargado del archivo.\nMBR fue guardado en el disco duro.")
de( MESG_MBR_SAVED2 = "Neuer MBR wurde eingeladen.\nMBR wurde geschrieben.")
ru( MESG_MBR_SAVED2 = "���� MBR ����㦥� � ������.\nMBR ��࠭� �� ���.")
fr( MESG_MBR_SAVED2 = "Nouveau MBR charg� d'un fichier.\nL'ancien MBR est sauv� sur le disque dur.")
it( MESG_MBR_SAVED2 = "Nuovi dati del MBR caricati da file.\nMBR salvato su disco rigido.")
nl( MESG_MBR_SAVED2 = "Nieuwe MBR is geladen.\nMBR is naar vaste schijf geschreven.")
cs( MESG_MBR_SAVED2 = "Nov� MBR byl zaveden ze souboru.\nMBR byl zaps�n na disk.")


en( MESG_INSTALL    = "New IPL code was installed in memory. Press F2 to save changes.")
se( MESG_INSTALL    = "Ny IPL kod �r installerad i minnet. Tryck F2 f�r att spara �ndringen.")
sp( MESG_INSTALL    = "Nueva IPL codigo instalado en memoria. Presione F2 para guardar cambios.")
de( MESG_INSTALL    = "Neuer IPL Code wurde geladen. F2 um ihn zu schreiben.")
ru( MESG_INSTALL    = "���� IPL ��⠭����� � �����. ������ F2 �⮡� ������� ���������.")
fr( MESG_INSTALL    = "Nouveau code IPL install� en m�moire. Presser F2 pour enregistrer.")
it( MESG_INSTALL    = "Nuovo codice per IPL installato in memoria. Premere F2 per salvare.")
nl( MESG_INSTALL    = "Nieuwe IPL code is geladen. Druk op F2 om de veranderingen op te slaan.")
cs( MESG_INSTALL    = "Nov� IPL byl zaveden. Stisknut�m <F2> jej zap��ete na disk.")

en( MESG_UNINSTALL  = "Standard IPL code was installed in memory. Press F2 to save changes.")
se( MESG_UNINSTALL  = "Standard IPL �r installerad i minnet. Tryck F2 f�r att spara �ndringen.")
sp( MESG_UNINSTALL  = "Standard IPL instalado en memoria. Presione F2 para guardar cambios.")
de( MESG_UNINSTALL  = "Standard IPL Code wurde geladen. F2 um ihn zu schreiben.")
ru( MESG_UNINSTALL  = "�⠭����� IPL ��⠭����� � �����. ������ F2 �⮡� ������� ���������.")
fr( MESG_UNINSTALL  = "Code IPL Standard install� en m�moire. Presser F2 pour enregistrer.")
it( MESG_UNINSTALL  = "IPL Standard installato in memoria. Premere F2 per salvare.")
nl( MESG_UNINSTALL  = "Standaard IPL code geladen. Druk op F2 om de veranderingen op te slaan.")
cs( MESG_UNINSTALL  = "Standardn� IPL byl zaveden. Stisknut�m <F2> jej zap��ete na disk.")

en( MESG_NOT_SAVED  = "MBR was modified. You have to SAVE or UNDO changes first.")
se( MESG_NOT_SAVED  = "MBR �r modifierad. Du m�ste SPARA eller UNDO f�r�ndringarna f�rst.")
sp( MESG_NOT_SAVED  = "MBR fue modificado. Debe guardar or deshacer cambios primero.")
de( MESG_NOT_SAVED  = "MBR wurde ver�ndert. Zuerst Sichern oder �nderungen zur�cknehmen.")
ru( MESG_NOT_SAVED  = "MBR ���������. �������� ᭠砫� SAVE ��� UNDO.")
fr( MESG_NOT_SAVED  = "Le MBR a �t� modifi�. Sauvegardez ou annulez d'abord la modification.")
it( MESG_NOT_SAVED  = "MBR modificato. Si deve ora SALVARE o ANNULLARE le modifiche.")
nl( MESG_NOT_SAVED  = "MBR is veranderd. U moet de veranderingen eerst opslaan of ongedaan maken.") 
cs( MESG_NOT_SAVED  = "MBR byl zm�n�n. Ulo�te nebo odvolejte zm�ny.")

en( MESG_LOGICAL = "Logical drives:\n\n")
se( MESG_LOGICAL = "Logiska enheter:\n\n")
sp( MESG_LOGICAL = "Logical drives:\n\n")
de( MESG_LOGICAL = "Logische Platten:\n\n")
ru( MESG_LOGICAL = "�����᪨� ��᪨:\n\n")
fr( MESG_LOGICAL = "Disques Logique:\n\n")
it( MESG_LOGICAL = "Dischi logici:\n\n")
nl( MESG_LOGICAL = "Logische stations:\n\n")
cs( MESG_LOGICAL = "Logick� disky:\n\n")

en( MESG_DIFFERENT      = "Differences found !!!")
se( MESG_DIFFERENT      = "Skillnad funnen !!!")
sp( MESG_DIFFERENT      = "Diferencias encontradas !!!")
de( MESG_DIFFERENT      = "Unterschiede gefunden !!!")
ru( MESG_DIFFERENT      = "������� ࠧ���� !!!")
fr( MESG_DIFFERENT      = "Il y a des diff�rences !!!")
it( MESG_DIFFERENT      = "Trovate differenze !!!")
nl( MESG_DIFFERENT      = "Verschillen gevonden !!!")
cs( MESG_DIFFERENT      = "Nalezeny rozd�ly !!!")

en( MESG_NO_DIFFERENCES = "No differences found.")
se( MESG_NO_DIFFERENCES = "Ingen skillnad funnen.")
sp( MESG_NO_DIFFERENCES = "No diferencias encontradas.")
de( MESG_NO_DIFFERENCES = "Keine Unterschiede gefunden.")
ru( MESG_NO_DIFFERENCES = "�����稩 �� �������.")
fr( MESG_NO_DIFFERENCES = "Pas de diff�rences.")
it( MESG_NO_DIFFERENCES = "Nessuna differenza trovata.")
nl( MESG_NO_DIFFERENCES = "Geen verschillen gevonden.")
cs( MESG_NO_DIFFERENCES = "Nenalezeny rozd�ly.")

en( HTML_DOC_EMPTY = "\nDocument is empty.\n")
se( HTML_DOC_EMPTY = "\nDokumentet �r tomt.\n")
sp( HTML_DOC_EMPTY = "\nDocumento esta vacio.\n")
de( HTML_DOC_EMPTY = "\nDas Dokument ist leer.\n")
ru( HTML_DOC_EMPTY = "\n���㬥�� ���⮩.\n")
fr( HTML_DOC_EMPTY = "\nLe document est vide.\n")
it( HTML_DOC_EMPTY = "\nIl documento � vuoto.\n")
nl( HTML_DOC_EMPTY = "\nDocument is leeg.\n")
cs( HTML_DOC_EMPTY = "\nDokument je pr�zdn�.\n")

en( HTML_NOT_FOUND = "Reference %s not found")
se( HTML_NOT_FOUND = "Referens %s icke funnen")
sp( HTML_NOT_FOUND = "Referencia %s no encontrada")
de( HTML_NOT_FOUND = "Referenzmarke %s nicht gefunden")
ru( HTML_NOT_FOUND = "������� %s � ����� ���")
fr( HTML_NOT_FOUND = "R�f�rence %s introuvable")
it( HTML_NOT_FOUND = "Riferimento %s non trovato")
nl( HTML_NOT_FOUND = "Referentie %s niet gevonden")
cs( HTML_NOT_FOUND = "Odkaz %s nebyl nalezen")

en( HTML_ERROR_READ = "Error reading file %s")
se( HTML_ERROR_READ = "Fel vid l�sning av fil %s")
sp( HTML_ERROR_READ = "Error leyendo archivo %s")
de( HTML_ERROR_READ = "Fehler beim Lesen der Datei %s")
ru( HTML_ERROR_READ = "�訡�� �� �⥭�� �� 䠩�� %s")
fr( HTML_ERROR_READ = "Erreur de lecture du fichier %s")
it( HTML_ERROR_READ = "Errore leggendo il file %s")
nl( HTML_ERROR_READ = "Fout tijdens lezen van het bestand %s")
cs( HTML_ERROR_READ = "Chyba p�i �ten� souboru %s")

en( ERROR_NO_SETUP  = "Setup module is not available for this file system.")
se( ERROR_NO_SETUP  = "Konfigurations modul �r inte tillg�nglig f�r detta fil system.")
sp( ERROR_NO_SETUP  = "Modulo de instalaci�n no esta disponible para este archivo.")
de( ERROR_NO_SETUP  = "Kein Setup Modul f�r dieses Dateisystem vorhanden.")
ru( ERROR_NO_SETUP  = "����� ��� ���䨣��樨 �⮩ 䠩����� ��⥬� ���� �� �������.")
fr( ERROR_NO_SETUP  = "Module de configuration non disponible pour ce syst�me de fichiers.")
it( ERROR_NO_SETUP  = "Modulo di installazione non disponibile per questo file system.")
nl( ERROR_NO_SETUP  = "Setup module is niet beschikbaar voor dit bestandssysteem.")
cs( ERROR_NO_SETUP  = "Pro tento syst�m nen� dostupn� nastavovac� modul.")

en( ERROR_NO_FORMAT = "Format module is not available for this file system.")
se( ERROR_NO_FORMAT = "Format modul �r inte tillg�nglig f�r detta fil system.")
sp( ERROR_NO_FORMAT = "Modulo de formateo no esta disponible para este archivo de sistema.")
de( ERROR_NO_FORMAT = "Kein Formatierungsmodul f�r dieses Dateisystem vorhanden.")
ru( ERROR_NO_FORMAT = "����� ��� �ଠ�஢���� �⮩ 䠩����� ��⥬� ���� �� �������.")
fr( ERROR_NO_FORMAT = "Module de formatage non disponible pour ce syst�me de fichiers.")
it( ERROR_NO_FORMAT = "Modulo di formattazione non disponibile per questo file system.")
nl( ERROR_NO_FORMAT = "Formatteer module is niet beschikbaar voor dit bestandssysteem.")
cs( ERROR_NO_FORMAT = "Pro tento syst�m nen� dostupn� form�tovac� modul.")
 
en( PROMPT_FILE    = "Enter file name: ")
se( PROMPT_FILE    = "Skriv fil namn: ")
sp( PROMPT_FILE    = "Entar nombre del archivo: ")
de( PROMPT_FILE    = "Dateiname: ")
ru( PROMPT_FILE    = "������ ��� 䠩��: ")
fr( PROMPT_FILE    = "Entrez le nom du fichier: ")
it( PROMPT_FILE    = "Inserire nome file: ")
nl( PROMPT_FILE    = "Bestandsnaam: ")
cs( PROMPT_FILE    = "Zadejte jm�no souboru: ")

en( PROMPT_FSTYPE  = "Enter file system id: ")
se( PROMPT_FSTYPE  = "Skriv fil system id: ")
sp( PROMPT_FSTYPE  = "Entrar el id del archivo del systema: ")
de( PROMPT_FSTYPE  = "Dateisystem ID: ")
ru( PROMPT_FSTYPE  = "������ �᭠������ ��� ��⥬�: ")
fr( PROMPT_FSTYPE  = "Entrez l'id du syst�me de fichiers: ")
it( PROMPT_FSTYPE  = "Inserire ID del file system: ")
nl( PROMPT_FSTYPE  = "Bestandssysteem identificatie: ")
cs( PROMPT_FSTYPE  = "Zadejte ��slo souborov�ho syst�mu: ")

en( PROMPT_FORMAT  = "Optional format arguments: ")
se( PROMPT_FORMAT  = "Ytterligare formaterings argument: ")
sp( PROMPT_FORMAT  = "Argumentos de formato opcional: ")
de( PROMPT_FORMAT  = "Optionale Formatparameter: ")
ru( PROMPT_FORMAT  = "������ ���� ��� �ଠ�, �᫨ ����: ")
fr( PROMPT_FORMAT  = "Arguments de formatage optionnels: ")
it( PROMPT_FORMAT  = "Argomenti opzionali di formattazione: ")
nl( PROMPT_FORMAT  = "Optionele formatteer parameters: ")
cs( PROMPT_FORMAT  = "Voliteln� parametry form�tov�n�: ")


en( MESG_CLEANING   = "^Cleaning...                                        Press ESC to cancel")
se( MESG_CLEANING   = "^Rensar...                                    Tryck ESC f�r att avbryta")
sp( MESG_CLEANING   = "^Borrando...                                 Presione ESC para cancelar")
de( MESG_CLEANING   = "^R�ume auf...                                         Abbrechen mit ESC")
ru( MESG_CLEANING   = "^���⨬...                                       ������ ESC ��� �⬥��")
fr( MESG_CLEANING   = "^Nettoyage...                                Pressez Echap pour annuler")
it( MESG_CLEANING   = "^Cancellazione...                             Premere ESC per annullare")
nl( MESG_CLEANING   = "^Bezig met schoonmaken...                   Druk op ESC om af te breken")
cs( MESG_CLEANING   = "^V�maz...                                      Odvolat stisknut�m <ESC>")

en( MESG_VERIFYING  = "^Verifying...                                       Press ESC to cancel")
se( MESG_VERIFYING  = "^Verifierar...                                Tryck ESC f�r att avbryta")
sp( MESG_VERIFYING  = "^Verificando...                              Presione ESC para cancelar")
de( MESG_VERIFYING  = "^Verifiziere...                                       Abbrechen mit ESC")
ru( MESG_VERIFYING  = "^��������...                                  ������ ESC ��� �⬥��")
fr( MESG_VERIFYING  = "^V�rification...                             Pressez Echap pour annuler")
it( MESG_VERIFYING  = "^Verifica...                                  Premere ESC per annullare")
nl( MESG_VERIFYING  = "^Bezig met controleren...                   Druk op ESC om af te breken")
cs( MESG_VERIFYING  = "^Kontrola...                                   Odvolat stisknut�m <ESC>")

en( MESG_FORMATTING = "^Formatting...                                      Press ESC to cancel")
se( MESG_FORMATTING = "^Formatterar...                               Tryck ESC f�r att avbryta")
sp( MESG_FORMATTING = "^Formatiando...                              Presione ESC para cancelar")
de( MESG_FORMATTING = "^Formatiere...                                        Abbrechen mit ESC")
ru( MESG_FORMATTING = "^��ଠ����...                                   ������ ESC ��� �⬥��")
fr( MESG_FORMATTING = "^Formatage...                                Pressez Echap pour annuler")
it( MESG_FORMATTING = "^Formattazione...                             Premere ESC per annullare")
nl( MESG_FORMATTING = "^Bezig met formatteren...                   Druk op ESC om af te breken")
cs( MESG_FORMATTING = "^Form�tov�n�...                                Odvolat stisknut�m <ESC>")

en( MESG_FORMAT_OK       = "Format completed.")
se( MESG_FORMAT_OK       = "Formattering slutf�rd.")
sp( MESG_FORMAT_OK       = "Formato completo.")
de( MESG_FORMAT_OK       = "Formatieren beendet.")
ru( MESG_FORMAT_OK       = "��ଠ� �����襭.")
fr( MESG_FORMAT_OK       = "Formatage termin�.")
it( MESG_FORMAT_OK       = "Formattazione completata.")
nl( MESG_FORMAT_OK       = "formatteren gereed.")
cs( MESG_FORMAT_OK       = "Form�tov�n� dokon�eno.")

en( WARN_FORMAT_CANCEL   = "Format canceled by user.")
se( WARN_FORMAT_CANCEL   = "Formattering avbruten av anv�ndare.")
sp( WARN_FORMAT_CANCEL   = "Formato cancelado por usuario.")
de( WARN_FORMAT_CANCEL   = "Formatierung abgebrochen.")
ru( WARN_FORMAT_CANCEL   = "��ଠ� �⬥�� ���짮��⥫��.")
fr( WARN_FORMAT_CANCEL   = "Formatage interrompu par l'utilisateur.")
it( WARN_FORMAT_CANCEL   = "Formattazione annullata dall'utente.")
nl( WARN_FORMAT_CANCEL   = "Formatteren is afgebroken.")
cs( WARN_FORMAT_CANCEL   = "Form�tov�n� p�eru�eno u�ivatelem.")

en( ERROR_FORMAT_FAILED  = "Format failed.")
se( ERROR_FORMAT_FAILED  = "Formattering misslyckades.")
sp( ERROR_FORMAT_FAILED  = "Formato fallo.")
de( ERROR_FORMAT_FAILED  = "Formatierung fehlgeschlagen.")
ru( ERROR_FORMAT_FAILED  = "��ଠ�஢���� �� ���﫮��.")
fr( ERROR_FORMAT_FAILED  = "Formatage rat�.")
it( ERROR_FORMAT_FAILED  = "Formattazione fallita.")
nl( ERROR_FORMAT_FAILED  = "Formatteren mislukt.")
cs( ERROR_FORMAT_FAILED  = "Form�tov�n� ukon�eno chybou.")

en( MESG_VERIFY_OK       = "Verification completed. No bad sectors found.")
se( MESG_VERIFY_OK       = "Verifiering avslutad. Inga d�liga sektorer funna.")
sp( MESG_VERIFY_OK       = "Verificaci�n completa. No encontro sectores malos.")
de( MESG_VERIFY_OK       = "Oberfl�chentest beendet. Keine Fehler gefunden.")
ru( MESG_VERIFY_OK       = "���䨪��� �����襭�. ������� ᥪ�஢ ���. �� ������.")
fr( MESG_VERIFY_OK       = "V�rification termin�e. Aucun secteur d�fectueux.")
it( MESG_VERIFY_OK       = "Verifica completata. Nessun settore difettoso.")
nl( MESG_VERIFY_OK       = "Controle voltooid. Geen slechte sectoren gevonden.")
cs( MESG_VERIFY_OK       = "Test povrchu dokon�en, vadn� sektory nebyly nalezeny.")

en( WARN_VERIFY_CANCEL   = "Verification canceled by user.")
se( WARN_VERIFY_CANCEL   = "Verifiering avbruten av anv�ndare.")
sp( WARN_VERIFY_CANCEL   = "Verificaci�n cancelada por usuario.")
de( WARN_VERIFY_CANCEL   = "Oberfl�chentest abgebrochen.")
ru( WARN_VERIFY_CANCEL   = "���䨪��� �⬥���� ���짮��⥫��.")
fr( WARN_VERIFY_CANCEL   = "V�rification interompue par l'utilisateur.")
it( WARN_VERIFY_CANCEL   = "Verifica annullata dall'utente.")
nl( WARN_VERIFY_CANCEL   = "Controle afgebroken.")
cs( WARN_VERIFY_CANCEL   = "Test povrchu p�eru�en u�ivatelem.")

en( ERROR_VERIFY_FAILED  = "One or more bad sectors found on disk.")
se( ERROR_VERIFY_FAILED  = "En eller flera d�liga sektorer funna p� disken.")
sp( ERROR_VERIFY_FAILED  = "Uno � mas sectores malos encontrados en el disco.")
de( ERROR_VERIFY_FAILED  = "Ein oder mehrere fehlerhafte Sektoren gefunden.")
ru( ERROR_VERIFY_FAILED  = "��� ������ ���� ᥪ�� ᡮ���.")
fr( ERROR_VERIFY_FAILED  = "Un ou plusieurs secteurs du disque sont d�fectueux.")
it( ERROR_VERIFY_FAILED  = "Uno o pi� settori difettosi trovati sul disco.")
nl( ERROR_VERIFY_FAILED  = "1 of meerdere slechte sectoren gevonden.")
cs( ERROR_VERIFY_FAILED  = "Nalezen alespo� jeden sektor s chybou.")
 

en( ERROR_FORMAT_GEN     = "General failure formatting the disk.")
se( ERROR_FORMAT_GEN     = "Generellt misslyckande att formattera disken.")
sp( ERROR_FORMAT_GEN     = "Error general formatiando el dico.")
de( ERROR_FORMAT_GEN     = "Schwerer Fehler beim Formatieren.")
ru( ERROR_FORMAT_GEN     = "General failure formatting the disk.")
fr( ERROR_FORMAT_GEN     = "Echec g�n�ral du formatage du disque dur.")
it( ERROR_FORMAT_GEN     = "Errore generale di formattazione.")
nl( ERROR_FORMAT_GEN     = "Algemene storing tijdens het formatteren.")
cs( ERROR_FORMAT_GEN     = "V��n� chyba p�i form�tov�n� disku.")

en( ERROR_FORMAT_WIN95   = "You must exit to Windows 95's DOS Prompt for destructive format.")
se( ERROR_FORMAT_WIN95   = "Du m�ste g� ut i DOS Prompt f�r en destruktiv formattering.")
sp( ERROR_FORMAT_WIN95   = "Ud. debe salir de Windows 95 DOS Prompt para destrucci�n de formato.")
de( ERROR_FORMAT_WIN95   = "Nur im Windows 95 Eingabemodus kann vollst�ndig Formatiert werden.")
ru( ERROR_FORMAT_WIN95   = "�� ������ ��� �� Windows 95 � DOS Prompt ��� ⠪��� ⨯� �ଠ�.")
fr( ERROR_FORMAT_WIN95   = "Vous devez red�marrer Windows 95 en mode MS-DOS pour le formatage.")
it( ERROR_FORMAT_WIN95   = "Si deve riavviare il sistema in modalit� MS-DOS per formattazione distruttiva.")
nl( ERROR_FORMAT_WIN95   = "Formatteren kan alleen in Windows 95 - MS-DOS modus.")
cs( ERROR_FORMAT_WIN95   = "Pro destruktivn� form�tov�n� mus�te p�ej�t do DOS re�imu Windows 95.")

en( ERROR_FORMAT_EMPTY   = "You cannot format or verify empty partition.")
se( ERROR_FORMAT_EMPTY   = "Du kan inte formattera eller verifiera tom partition.")
sp( ERROR_FORMAT_EMPTY   = "Ud. no puede formatear � verificar partici�n vacia.")
de( ERROR_FORMAT_EMPTY   = "Befehl f�r leere Partitionen nicht ausf�hrbar.")
ru( ERROR_FORMAT_EMPTY   = "����� ࠧ���� �� �ଠ������� � �� ��� �� ������.")
fr( ERROR_FORMAT_EMPTY   = "Impossible de formater ou v�rifier une partition vide.")
it( ERROR_FORMAT_EMPTY   = "Non si pu� formattare o verificare una partizione vuota.")
nl( ERROR_FORMAT_EMPTY   = "Formatteren of controleren van lege partitie onmogelijk.")
cs( ERROR_FORMAT_EMPTY   = "Nem��ete form�tovat nebo kontrolovat pr�zdnou oblast.")

en( ERROR_FORMAT_FRACTION = "Cannot format partition with fractional sides on the ends.")
se( ERROR_FORMAT_FRACTION = "Kan inte formattera partition med splittrade sidor p� slutet.")
sp( ERROR_FORMAT_FRACTION = "No puede formatear partici�n con lados fracionales en el final.")
de( ERROR_FORMAT_FRACTION = "Partition mit losen Enden kann nicht formatiert werden.")
ru( ERROR_FORMAT_FRACTION = "������ �� ������ ����� �஡��� ��஭ �� �����.")
fr( ERROR_FORMAT_FRACTION = "Impossible de formater une partition dont la fin est fractionn�e.")
it( ERROR_FORMAT_FRACTION = "Impossibile formattare partizioni con valori frazionari.")
nl( ERROR_FORMAT_FRACTION = "Partitie met gebroken einden kan niet geformatteerd worden.")
cs( ERROR_FORMAT_FRACTION = "Oblast s ne�pln�m koncem nelze form�tovat.")
 

en( IPL_VIRUS   = "Check for MBR viruses ..")
se( IPL_VIRUS   = "Kolla MBR virusar ......")
sp( IPL_VIRUS   = "Verificar MBR virus ....")
de( IPL_VIRUS   = "Pr�fe MBR auf Viren ....")
ru( IPL_VIRUS   = "�஢�ઠ �� ������ .....")
fr( IPL_VIRUS   = "V�rifie les virus MBR ..")
it( IPL_VIRUS   = "Controllo virus MBR ....")
nl( IPL_VIRUS   = "Controleer op MBR virus.")
cs( IPL_VIRUS   = "Hled�m viry v MBR   ....")

en( IPL_DOTS    = "Number of running dots .")
se( IPL_DOTS    = "Prickig prompt l�ngd ...")
sp( IPL_DOTS    = "Puntos sucesivos .......")
de( IPL_DOTS    = "Zahl der Eingabepunkte .")
ru( IPL_DOTS    = "������⢮ ��祪 .....")
fr( IPL_DOTS    = "Nombre de points .......")
it( IPL_DOTS    = "Numero puntini .........")
nl( IPL_DOTS    = "Aantal punten...........")
cs( IPL_DOTS    = "Po�et bod� .............")

en( IPL_DEFAULT = "Default partition name .")
se( IPL_DEFAULT = "Standard part. namn ....")
sp( IPL_DEFAULT = "Partici�n inicial ......")
de( IPL_DEFAULT = "Default Partitionsname .")
ru( IPL_DEFAULT = "�ᥣ�� �।������ ......")
fr( IPL_DEFAULT = "Partition par d�faut....")
it( IPL_DEFAULT = "Partizione iniziale ....")
nl( IPL_DEFAULT = "Standaard partitienaam..")
cs( IPL_DEFAULT = "Implicitn� jm�no oblasti")

en( IPL_NOACTV  = "If no prt active boot ..")
se( IPL_NOACTV  = "Om inga prt aktiva boota")
sp( IPL_NOACTV  = "Si no prt boot activo ..")
de( IPL_NOACTV  = "Wenn kein Prt, starte ..")
ru( IPL_NOACTV  = "��� ⥪�饣� ��㧨�� ...")
fr( IPL_NOACTV  = "Pas de prt active, boot.")
it( IPL_NOACTV  = "Se non bootstrappa .....")
nl( IPL_NOACTV  = "Indien geen Prt. start..")
cs( IPL_NOACTV  = "Start nen�-li aktivn� ob")

en( MENU_ADV_OPT_TITLE    = "Menu title:")
se( MENU_ADV_OPT_TITLE    = "Meny titel:")
sp( MENU_ADV_OPT_TITLE    = "Titulo:"    )
de( MENU_ADV_OPT_TITLE    = "Menu Titel:")
ru( MENU_ADV_OPT_TITLE    = "���������:" )
fr( MENU_ADV_OPT_TITLE    = "Titre du menu:")
it( MENU_ADV_OPT_TITLE    = "Titolo:"    )
nl( MENU_ADV_OPT_TITLE    = "Menu titel:")
cs( MENU_ADV_OPT_TITLE    = "N�zev nab�dky:")

en( MENU_ADV_OPT_TIMEOUT  = "Boot menu timeout:" )
se( MENU_ADV_OPT_TIMEOUT  = "Boot meny avbrott:" )
sp( MENU_ADV_OPT_TIMEOUT  = "Finalizo boot menu:")
de( MENU_ADV_OPT_TIMEOUT  = "Boot Menu Timeout:" )
ru( MENU_ADV_OPT_TIMEOUT  = "�६� ��������:"    )
fr( MENU_ADV_OPT_TIMEOUT  = "Limite de temps:"   )
it( MENU_ADV_OPT_TIMEOUT  = "Scadenza boot menu:")
nl( MENU_ADV_OPT_TIMEOUT  = "Boot menu time-out:")
cs( MENU_ADV_OPT_TIMEOUT  = "Timeout zav. nab.:" )

en( MENU_ADV_OPT_VIRCHECK = "Check for viruses:" )
se( MENU_ADV_OPT_VIRCHECK = "Kolla f�r virus:"   )
sp( MENU_ADV_OPT_VIRCHECK = "Buscar virus:"      )
de( MENU_ADV_OPT_VIRCHECK = "Auf Viren pr�fen:"  )
ru( MENU_ADV_OPT_VIRCHECK = "�஢�ઠ �� ������:")
fr( MENU_ADV_OPT_VIRCHECK = "Antivirus MBR:"     )
it( MENU_ADV_OPT_VIRCHECK = "Controllo virus:"   )
nl( MENU_ADV_OPT_VIRCHECK = "Viruscontrole:"     )
cs( MENU_ADV_OPT_VIRCHECK = "Kontrolovat viry:"  )

en( MENU_ADV_OPT_CLEARSCR = "Clear screen:"      )
se( MENU_ADV_OPT_CLEARSCR = "Rensa sk�rmen:"     )
sp( MENU_ADV_OPT_CLEARSCR = "Limpiar pantalla:"  )
de( MENU_ADV_OPT_CLEARSCR = "Bildschirm l�schen:")
ru( MENU_ADV_OPT_CLEARSCR = "������ ��࠭:"     )
fr( MENU_ADV_OPT_CLEARSCR = "Effacer l'�cran:"   )
it( MENU_ADV_OPT_CLEARSCR = "Cancella schermo:"  )
nl( MENU_ADV_OPT_CLEARSCR = "Maak scherm leeg:"  )
cs( MENU_ADV_OPT_CLEARSCR = "Smazat obrazovku:"  )

en( MENU_ADV_OPT_DEFAULT  = "Default boot menu:" )
se( MENU_ADV_OPT_DEFAULT  = "Standard boot meny:")
sp( MENU_ADV_OPT_DEFAULT  = "Inicial menu boot:" )
de( MENU_ADV_OPT_DEFAULT  = "Default Boot Menu:" )
ru( MENU_ADV_OPT_DEFAULT  = "��砫쭮� ����:"    )
fr( MENU_ADV_OPT_DEFAULT  = "Menu par d�faut:"   )
it( MENU_ADV_OPT_DEFAULT  = "Menu boot standard:")
nl( MENU_ADV_OPT_DEFAULT  = "Standaard menu:"    )
cs( MENU_ADV_OPT_DEFAULT  = "Impl. zav. nab�dka:")

en( MENU_ADV_OPT_PASSWORD = "Menu password:"     )
se( MENU_ADV_OPT_PASSWORD = "Menu password:"     )
sp( MENU_ADV_OPT_PASSWORD = "Contrasena menu:"   )
de( MENU_ADV_OPT_PASSWORD = "Menu password:"     )
ru( MENU_ADV_OPT_PASSWORD = "��஫�:"            )
fr( MENU_ADV_OPT_PASSWORD = "Mot de passe:"      )
it( MENU_ADV_OPT_PASSWORD = "Menu password:"     )
nl( MENU_ADV_OPT_PASSWORD = "Menu wachtwoord:"   )
cs( MENU_ADV_OPT_PASSWORD = "Heslo nab�dky:"     )

en( MENU_ADV_OPT_IGN_UNUSED = "Ignore unused part:")
se( MENU_ADV_OPT_IGN_UNUSED = "Ignore unused part:")
sp( MENU_ADV_OPT_IGN_UNUSED = "Ignore unused part:")
de( MENU_ADV_OPT_IGN_UNUSED = "Ignore unused part:")
ru( MENU_ADV_OPT_IGN_UNUSED = "Ignore unused part:")
fr( MENU_ADV_OPT_IGN_UNUSED = "Ignore unused part:")
it( MENU_ADV_OPT_IGN_UNUSED = "Ignore unused part:")
nl( MENU_ADV_OPT_IGN_UNUSED = "Ignore unused part:")

en( NAME_OS_UNUSED = "Unused")
se( NAME_OS_UNUSED = "Unused")
sp( NAME_OS_UNUSED = "Sin uso")
de( NAME_OS_UNUSED = "Leer")
ru( NAME_OS_UNUSED = "�� ��.")
fr( NAME_OS_UNUSED = "Inutilis�")
it( NAME_OS_UNUSED = "Non usato")
nl( NAME_OS_UNUSED = "Ongebruikt")
cs( NAME_OS_UNUSED = "Nevyu�ito")

en( NAME_OS_ADV    = "Advanced Boot Manager")
se( NAME_OS_ADV    = "Advanced Boot Manager")
sp( NAME_OS_ADV    = "Boot Manager Avansado")
de( NAME_OS_ADV    = "Advanced Boot Manager")
ru( NAME_OS_ADV    = "Advanced Boot Manager")
fr( NAME_OS_ADV    = "Boot Manager Avanc�"  )
it( NAME_OS_ADV    = "Boot Manager Avanzato")
nl( NAME_OS_ADV    = "Advanced Boot Manager")
cs( NAME_OS_ADV    = "Roz��en� Boot Manager")

en( NAME_OS_HIDDEN = "Hidden (0xFF)")
se( NAME_OS_HIDDEN = "G�md (0xFF)")
sp( NAME_OS_HIDDEN = "Escondido (0xFF)")
de( NAME_OS_HIDDEN = "Versteckt (0xFF)")
ru( NAME_OS_HIDDEN = "����⠭ (0xFF)")
fr( NAME_OS_HIDDEN = "Cach� (0xFF)")
it( NAME_OS_HIDDEN = "Nascosto (0xFF)")
nl( NAME_OS_HIDDEN = "Verborgen (0xFF)")
cs( NAME_OS_HIDDEN = "Skryto (0xFF)")

en( NAME_OS_UNKN   = "Unknown (0x%02X)         ")
se( NAME_OS_UNKN   = "Ok�nd (0x%02X)           ")
sp( NAME_OS_UNKN   = "No conocido (0x%02X)     ")
de( NAME_OS_UNKN   = "Unbekannt (0x%02X)       ")
ru( NAME_OS_UNKN   = "��������� (0x%02X)     ")
fr( NAME_OS_UNKN   = "Inconnu (0x%02X)         ")
it( NAME_OS_UNKN   = "Sconosciuto (0x%02X)     ")
nl( NAME_OS_UNKN   = "Onbekend (0x%02X)        ")
cs( NAME_OS_UNKN   = "Nezn�mo (0x%02X)         ")


en( MESG_NON_SYSTEM = "\r\nSystem is not installed."
                      "\r\nHit a key to reboot...") 
se( MESG_NON_SYSTEM = "\r\nSystem �r inte installerat."
                      "\r\nTryck en tangent f�r reboot...")
sp( MESG_NON_SYSTEM = "\r\nSistema no esta instalado."
                      "\r\nPresione una tecla para reiniciar...")
de( MESG_NON_SYSTEM = "\r\nKein System installiert."
                      "\r\nTaste um das System neu zu starten...") 
ru( MESG_NON_SYSTEM = "\r\n���⥬�� 䠩�� ����������."
                      "\r\n������ ���� ������� ...")
fr( MESG_NON_SYSTEM = "\r\nPas de syst�me install�."
                      "\r\nPressez une touche pour red�marrer...")
it( MESG_NON_SYSTEM = "\r\nSistema non installato."
                      "\r\nPremere un tasto per riavviare...")
nl( MESG_NON_SYSTEM = "\r\nSysteem niet geinstalleerd."
                      "\r\nDruk een toets om te herstarten...")
cs( MESG_NON_SYSTEM = "\r\nSyst�m nen� instalov�n."
                      "\r\nPro restartov�n� stiskn�te kl�vesu...") 


en( MESG_EXT_NONBOOT ="\r\nExtended partition is not bootable."
                      "\r\nHit a key to reboot...")
se( MESG_EXT_NONBOOT ="\r\nUt�kade partitionrn �r inte bootbar."
                      "\r\nTryck en tangent f�r att boota om...")
sp( MESG_EXT_NONBOOT ="\r\nPartici�n extendida no es bootable."
                      "\r\nPresionar una tecla para reiniciar...")
de( MESG_EXT_NONBOOT ="\r\nExtended Partition ist nicht startbar."
                      "\r\nTaste um das System neu zu starten...") 
ru( MESG_EXT_NONBOOT ="\r\n����७�� ࠧ��� �� ����㧮��."
                      "\r\n������ ���� ������� ...")
fr( MESG_EXT_NONBOOT ="\r\nPartition Etendue non bootable."
                      "\r\nPressez une touche pour red�marrer...")
it( MESG_EXT_NONBOOT ="\r\nPartizione estesa non avviabile."
                      "\r\nPremere un tasto per riavviare...")
nl( MESG_EXT_NONBOOT ="\r\nUitgebreide partitie niet startbaar."
                      "\r\nDruk een toets om te herstarten.")
cs( MESG_EXT_NONBOOT ="\r\nZ roz��en� oblasti nelze zav�st syst�m."
                      "\r\nPro restartov�n� stiskn�te kl�vesu...") 

en( HELP_FILE_NAME = "part.htm")
se( HELP_FILE_NAME = "part.htm")
sp( HELP_FILE_NAME = "part.htm")
de( HELP_FILE_NAME = "part.htm")
ru( HELP_FILE_NAME = "part.htm")
fr( HELP_FILE_NAME = "part.htm")
it( HELP_FILE_NAME = "part.htm")
nl( HELP_FILE_NAME = "part.htm")
cs( HELP_FILE_NAME = "part.htm")

en( HELP_CMD_LINE = 

"Ranish Partition Manager    Version "VERSION"\n\n"

"Usage: part [-q] [-d disk] [-command ...]\n\n"

" part          - Interactive mode\n"
" part -i       - Print IDE disk info\n"
" part -p       - Print partition table\n"
" part -p -r    - Print info recursively\n"
" part -a n     - Activate n-th partition\n"
" part -h n     - Hide/unhide n-th partition\n"
" part -v n     - Verify n-th partition\n"
" part -f n ... - Format n-th partition\n"
" part -s file  - Save MBR to file\n"
" part -l file  - Load MBR from file\n"
" part -c file  - Compare MBR with file\n"
" part -Reboot  - Reboot computer\n\n"

"Homepage: "HOME_URL"\n")
se( HELP_CMD_LINE      =  

"Ranish Partition Manager    Version "VERSION"\n\n"

"Anv�ndning: part [-q] [-d disk] [-kommand ...]\n\n"

" part          - Interaktivt l�ge\n"
" part -i       - Skriv ut IDE disk info\n"
" part -p       - Skriv ut partition tabell\n"
" part -p -r    - Skriv ut info rekursivt\n"
" part -a n     - Aktivera n-th partition\n"
" part -h n     - Hide/unhide n-th partition\n"
" part -v n     - Verifiera n-th partition\n"
" part -f n ... - Formattera n-th partition\n"
" part -s fil   - Spara MBR till en fil\n"
" part -l fil   - Ladda MBR fr�n en fil\n"
" part -c file  - J�mf�r MBR med fil\n"
" part -Reboot  - Boota om datorn\n\n"

"Produkt hem: "HOME_URL"\n")
sp( HELP_CMD_LINE = 

"Ranish Partition Manager    Versi�n "VERSION"\n\n"

"Usage: part [-q] [-d disk] [-command ...]\n\n"

" part          - Modo Interactivo \n"
" part -i       - Imprimir disco info IDE\n"
" part -p       - Imprimir tabla de partici�n\n"
" part -p -r    - Imprimir info recursivamente\n"
" part -a n     - Activar n-ava partici�n\n"
" part -h n     - Hide/unhide n-th partition\n"
" part -v n     - Verificar n-ava partici�n\n"
" part -f n ... - Formatear n-ava partici�n\n"
" part -s file  - Guardar MBR en un archivo\n"
" part -l file  - Cargar MBR de un archivo\n"
" part -c file  - Compare MBR con archivo\n"
" part -Reboot  - Reboot computadora\n\n"

"Homepage: "HOME_URL"\n")
de( HELP_CMD_LINE = 

"Ranish Partition Manager    Version "VERSION"\n\n"

"Aufruf: part [-q] [-d Platte] [-Kommando ...]\n\n"

" part          - Interaktiver Modus\n"
" part -i       - IDE Infos anzeigen\n"
" part -p       - Partitionstabelle anzeigen\n"
" part -p -r    - Alle Partitionstabellen anzeigen\n"
" part -a n     - Mache n-te Partition startbar\n"
" part -h n     - Hide/unhide n-th partition\n"
" part -v n     - �berpr�fe n-te Partition\n"
" part -f n ... - Formatiere n-te Partition\n"
" part -s Datei - Speichere MBR in eine Datei\n"
" part -l Datei - Lade MBR aus einer Datei\n"
" part -c Datei - Vergleiche MBR mit Datei\n"
" part -Reboot  - Rechner neu starten\n\n"

"Bezugsquelle: "HOME_URL"\n")
ru( HELP_CMD_LINE = 

"Ranish Partition Manager    Version "VERSION"\n\n"

"Usage: part [-q] [-d disk] [-command ...]\n\n"

" part          - ���ࠪ⨢�� ०��"
" part -i       - �������� IDE disk info\n"
" part -p       - �������� ⠡���� ࠧ�����\n"
" part -p -r    - �������� ���, �� �����\n"
" part -a n     - ������� ࠧ��� n ⥪�騬 (��⨢��)\n"
" part -a n     - ��⨢���஢��� n-�� ࠧ���\n"
" part -h n     - Hide/unhide n-th partition\n"
" part -v n     - �����஢��� n-�� ࠧ���\n"
" part -f n ... - ���ଠ�஢��� n-�� ࠧ���\n"
" part -s file  - ���࠭��� MBR � 䠩�\n"
" part -l file  - ����㧨�� MBR �� 䠩��\n"
" part -c file  - �ࠢ���� MBR � 䠩���\n"
" part -Reboot  - ��ॣ�㧨�� ��������\n\n"

"Homepage: "HOME_URL"\n")
fr( HELP_CMD_LINE = 

"Ranish Partition Manager    Version "VERSION"\n\n"

"Utilisation: part [-q] [-d disque] [-commande ...]\n\n"

" part          - Mode interactif\n"
" part -i       - Affiche les informations du disque IDE\n"
" part -p       - Affiche la table de partition\n"
" part -p -r    - Affiche les informations de mani�re r�cursive\n"
" part -a n     - Active la partition n� n\n"
" part -h n     - Hide/unhide n-th partition\n"
" part -v n     - Verifie la partition n� n\n"
" part -f n ... - Formate la partition n� n\n"
" part -s file  - Sauve le MBR dans un fichier\n"
" part -l file  - Charge le MBR � partir d'un fichier\n"
" part -c file  - Compare le MBR avec un fichier\n"
" part -Reboot  - Red�marre l'ordinateur\n\n"

"Site du produit: "HOME_URL"\n")
it( HELP_CMD_LINE = 

"Ranish Partition Manager    Version "VERSION"\n\n"

"Usage: part [-q] [-d disk] [-command ...]\n\n"

" part          - Modo Interattivo \n"
" part -i       - Stampa informazioni disco IDE\n"
" part -p       - Stampa tabella delle partizioni\n"
" part -p -r    - Stampa continua informazioni\n"
" part -a n     - Attiva n-esima partizione\n"
" part -h n     - Hide/unhide n-th partition\n"
" part -v n     - Verifica n-esima partizione\n"
" part -f n ... - Formatta n-esima partizione\n"
" part -s file  - Salva MBR su file\n"
" part -l file  - Carica MBR da file\n"
" part -c file  - Confronta MBR con file\n"
" part -Reboot  - Riavvia computer\n\n"

"Homepage: "HOME_URL"\n")
nl( HELP_CMD_LINE = 

"Ranish Partition Manager    Versie "VERSION"\n\n"

"Gebruik: part [-q] [-d disk] [-command ...]\n\n"

" part          - Interactieve modus\n"
" part -i       - Toon informatie over de IDE-schijf\n"
" part -p       - Toon partitie informatie\n"
" part -p -r    - Toon alle partitie tabellen\n"
" part -a n     - Activeer de n-ste partitie\n"
" part -h n     - Hide/unhide n-th partition\n"
" part -v n     - Controleer de n-ste partitie\n"
" part -f n ... - Formatteer de n-ste partitie\n"
" part -s file  - Sla de MBR op naar een bestand\n"
" part -l file  - Laad de MBR vanuit een bestand\n"
" part -c file  - Vergelijk de MBR met een bestand\n"
" part -Reboot  - Herstart de computer\n\n"

"Homepage: "HOME_URL"\n")
cs( HELP_CMD_LINE = 

"Ranish Partition Manager    Verze "VERSION"\n\n"

"Spu�t�n�: part [-q] [-d disk] [-p��kaz ...]\n\n"

" part           - Interaktivn� re�im\n"
" part -i        - Zobrazit informace o IDE\n"
" part -p        - Zobrazit tabulku oblast�\n"
" part -p -r     - Zobrazit v�echny oblasti\n"
" part -a n      - U�init n-tou oblast aktivn�\n"
" part -h n      - Hide/unhide n-th partition\n"
" part -v n      - Kontrolovat n-tou oblast\n"
" part -f n ...  - Form�tovat n-tou oblast\n"
" part -s soubor - Uschovat MBR do souboru\n"
" part -l soubor - Obnovit MBR ze souboru\n"
" part -c soubor - Porovnat MBR se souborem\n"
" part -Reboot   - Restartovat po��ta�\n\n"

"Dom�c� adresa: "HOME_URL"\n")

 i=0;
 os_desc[i].name = NAME_OS_UNUSED;
 while( os_desc[i].os_id!=OS_HIDDEN ) i++;
 os_desc[i].name = NAME_OS_HIDDEN;
 while( os_desc[i].os_id!=OS_ADV ) i++;
 os_desc[i].name = NAME_OS_ADV;
 while( os_desc[i].os_id!=OS_UNKN ) i++;
 os_desc[i].name = NAME_OS_UNKN;

}/* set_messages */
