// SPARC.h

#ifndef __SPARC_H
#define __SPARC_H

#include "BranchCoder.h"

MyClassA(BC_SPARC, 0x08, 5)

#endif
