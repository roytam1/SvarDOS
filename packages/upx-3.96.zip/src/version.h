#define UPX_VERSION_HEX         0x036000        /* 03.96.00 */
#define UPX_VERSION_STRING      "3.96"
#define UPX_VERSION_STRING4     "3.96"
#define UPX_VERSION_DATE        "Jan 23rd 2020"
#define UPX_VERSION_DATE_ISO    "2020-01-23"
#define UPX_VERSION_YEAR        "2020"

/* vim:set ts=4 sw=4 et: */
