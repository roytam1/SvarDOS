#ifndef __PRINT_HH__
#define __PRINT_HH__

#ifdef ENABLE_PRINTER

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


void a_Print_page(void *vbw);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* ENABLE_PRINTER */

#endif /* __PRINT_HH__ */
