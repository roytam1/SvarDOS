#ifndef CHK_ARGS_H_
#define CHK_ARGS_H_

BOOL IsInteractive(void);
BOOL MustListAllFiles(void);

void SetInteractive(void);
void IndicateAllFileListing(void);

#endif