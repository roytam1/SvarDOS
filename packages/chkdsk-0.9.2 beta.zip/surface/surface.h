#ifndef SURFACE_H_
#define SURFACE_H_

BOOL ScanSurface(RDWRHandle handle);

#endif
