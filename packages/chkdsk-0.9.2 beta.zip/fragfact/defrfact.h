#ifndef DEFRAG_FACTOR_H_
#define DEFRAG_FACTOR_H_

int PrintFileDefragFactors(RDWRHandle handle, char* abspath);

#endif
