int main()
{
  FlushAllCaches();

  delay(1000);

  Reboot(0);
}
