#ifndef STRNICMP_H_

int
strnicmp(const char *s1, const char *s2, size_t n);

#endif
