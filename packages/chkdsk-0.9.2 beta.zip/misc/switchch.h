#ifndef SWITCHCHAR_H_
#define SWITCHCHAR_H_

char SwitchChar(void);

#endif
