Word Whiz Release Notes - March 2009
Word Whiz is (c)1988/2009 Apogee Software, Ltd.
------------------------------------------------

This game was deleted from Apogee's product line a VERY long time ago, and 
has been re-released as freeware in March of 2009.  There are a few notes
you should be aware of with the release.

1) We offer no support in helping to getting this freeware release running.  
   You are on your own in getting it working.

2) This game does not handle modern computers very well, and as such 
   requires a third party program to help your computer adapt to the game
   better.  We strongly recommend the use of MoSlo, a program that can make
   a program think the computer is slower.  We have a demo version of this
   program in the "Miscellaneous Files" section of our downloads page here:
   http://www.3drealms.com/downloads.html

3) The registration information mentioned inside the game no longer exists; 
   no one lives at the addresses mentioned in the documentation.  Please do
   not try and contact anyone with this info - if someone is there, it's not
   us, you'll just be bothering someone who has no idea what you're talking 
   about.

4) This game is released as freeware.  That's not to be confused with 
   public domain, abandonware (which is illegal), or releasing something 
   under the GPL.   This is a freeware release, which means we retain full 
   legal rights to the title and it's materials.  You are free to play the 
   game as we've released it, but not free to "do whatever you want with 
   it", which includes selling it or otherwise using the materials for your
   own gain.

5) This game was originally released as freeware in December of 2005.  It is
   being re-released again in March of 2009 to include the source code.  This
   was discovered when doing research into source code for our old Kroz game.

Enjoy Word Whiz!
-- Apogee Tech Support, March 2009

----------------------------------------------------

Source Code Notes:

============================================
Word Whiz Source Code Release - Mar 20, 2009
============================================

LEGAL STUFF
-----------

"Word Whiz" is a registered trademark of Apogee Software, Ltd.
"Word Whiz" copyright 1987 - 2009 Apogee Software, Ltd.  All trademarks and copyrights reserved.

This is the extent of our source code archives for Supernova as pulled from the dusty archives of Scott Miller's old floppy discs.  This is all we know to still exist. 

The code is licensed under the terms of the GPL (gnu public license).  You should read the entire license (filename "GNU.TXT" in this archive), so you understand your rights and what you can and cannot do with the source code from this release.

Please do not contact us for possible commercial exploitation of this title -- we will not be interested.

Please note that this is being released without any kind of support from Apogee Software, Ltd / 3D Realms Entertainment.  We cannot help in getting this running and we do not guarantee that you will be able to get it to work, nor do we guarantee that it won't blow up your computer if you do try and use it.  We don't even guarantee it will compile!  Use at your own risk.

