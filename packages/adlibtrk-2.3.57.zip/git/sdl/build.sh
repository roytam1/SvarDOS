#!/bin/sh
for i in *.pp; do ppc386 $i; done