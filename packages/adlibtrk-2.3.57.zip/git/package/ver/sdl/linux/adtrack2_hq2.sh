#!/bin/sh
./adtrack2 /cfg:sdl_screen_mode=2 /cfg:sdl_frame_rate=150
