Information about the package
-----------------------------

Note: Please read the file doskey.txt for detailed usage about the program.

This package contains Enhanced DOSKEY, the DOS command line enhancement
program designed to replace doskey.com shipped with DOS and Windows 9x/Me.
The doskey.txt file is supplied as the main documentation for this program.
Please go to http://paulhoule.com/doskey for the latest info and downloads.

As of September 11, 2011, Enhanced DOSKEY is distributed as Free Software
under the GNU General Public License, version 2.0 (see src\gpl-2.0.txt).
Full source code (in assembly language) is included in the src\ folder.
The Windows jwbuild.bat script is provided to build the doskey.com image.

Copyright (c) 2011 Paul Houle and 2018 Wengier. All rights reserved.

===========================================================================

The software was previously (2009) available under the Freeware Licence.

Copyright (c) 2009 by Paul Houle (paulhoule.com). All rights reserved.
