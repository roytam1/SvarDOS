Multiple log files are kept here for debugging purposes.  Log files
are rotated keeping the latest 6 logs.
