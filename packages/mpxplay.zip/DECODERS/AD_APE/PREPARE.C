//**************************************************************************
//*                   This file is part of the                             *
//*           APE decoder of Mpxplay (http://mpxplay.cjb.net)              *
//*      based on the MAC SDK v3.97 (http://www.monkeysaudio.com)          *
//**************************************************************************
//*   This program is distributed in the hope that it will be useful,      *
//*   but WITHOUT ANY WARRANTY; without even the implied warranty of       *
//*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 *
//**************************************************************************

#include "All.h"
#include "Prepare.h"

static const unsigned __int32 CRC32_TABLE[256] =
{0,1996959894,3993919788,2567524794,124634137,1886057615,3915621685,2657392035,
 249268274,2044508324,3772115230,2547177864,162941995,2125561021,3887607047,
 2428444049,498536548,1789927666,4089016648,2227061214,450548861,1843258603,
 4107580753,2211677639,325883990,1684777152,4251122042,2321926636,335633487,
 1661365465,4195302755,2366115317,997073096,1281953886,3579855332,2724688242,
 1006888145,1258607687,3524101629,2768942443,901097722,1119000684,3686517206,
 2898065728,853044451,1172266101,3705015759,2882616665,651767980,1373503546,
 3369554304,3218104598,565507253,1454621731,3485111705,3099436303,671266974,
 1594198024,3322730930,2970347812,795835527,1483230225,3244367275,3060149565,
 1994146192,31158534,2563907772,4023717930,1907459465,112637215,2680153253,
 3904427059,2013776290,251722036,2517215374,3775830040,2137656763,141376813,
 2439277719,3865271297,1802195444,476864866,2238001368,
 4066508878,1812370925,453092731,2181625025,4111451223,1706088902,314042704,
 2344532202,4240017532,1658658271,366619977,2362670323,4224994405,1303535960,
 984961486,2747007092,3569037538,1256170817,1037604311,2765210733,3554079995,
 1131014506,879679996,2909243462,3663771856,1141124467,855842277,2852801631,
 3708648649,1342533948,654459306,3188396048,3373015174,1466479909,544179635,
 3110523913,3462522015,1591671054,702138776,2966460450,3352799412,1504918807,
 783551873,3082640443,3233442989,3988292384,2596254646,62317068,1957810842,
 3939845945,2647816111,81470997,1943803523,3814918930,2489596804,225274430,
 2053790376,3826175755,2466906013,167816743,2097651377,4027552580,2265490386,
 503444072,1762050814,4150417245,2154129355,426522225,1852507879,4275313526,
 2312317920,282753626,1742555852,4189708143,2394877945,397917763,1622183637,
 3604390888,2714866558,953729732,1340076626,3518719985,2797360999,1068828381,
 1219638859,3624741850,
 2936675148,906185462,1090812512,3747672003,2825379669,829329135,1181335161,
 3412177804,3160834842,628085408,1382605366,3423369109,3138078467,570562233,
 1426400815,3317316542,2998733608,733239954,1555261956,3268935591,3050360625,
 752459403,1541320221,2607071920,3965973030,1969922972,40735498,2617837225,
 3943577151,1913087877,83908371,2512341634,3803740692,2075208622,213261112,
 2463272603,3855990285,2094854071,198958881,2262029012,4057260610,1759359992,
 534414190,2176718541,4139329115,1873836001,414664567,2282248934,4279200368,
 1711684554,285281116,2405801727,4167216745,1634467795,376229701,2685067896,
 3608007406,1308918612,956543938,2808555105,3495958263,1231636301,1047427035,
 2932959818,3654703836,1088359270,936918000,2847714899,3736837829,1202900863,
 817233897,3183342108,3401237130,1404277552,615818150,3134207493,3453421203,
 1423857449,601450431,3009837614,3294710456,1567103746,711928724,3020668471,
 3272380065,1510334235,755167117
};


void apedec_UnprepareNew(int X,int Y,WAVEFORMATEX * pWaveFormatEx,unsigned char *pOutput,unsigned int * pCRC)
{
 #define CALCULATE_CRC_BYTE  *pCRC = (*pCRC >> 8) ^ CRC32_TABLE[(*pCRC & 0xFF) ^ *pOutput++];

 if (pWaveFormatEx->nChannels == 2){
  if (pWaveFormatEx->wBitsPerSample == 16){
   int nR = X - (Y / 2);
   int nL = nR + Y;

   if ((nR < -32768) || (nR > 32767) || (nL < -32768) || (nL > 32767)){
    return; // ???
   }

   *(__int16 *) pOutput = (__int16) nR;
   CALCULATE_CRC_BYTE
   CALCULATE_CRC_BYTE

   *(__int16 *) pOutput = (__int16) nL;
   CALCULATE_CRC_BYTE
   CALCULATE_CRC_BYTE
  }else
   if (pWaveFormatEx->wBitsPerSample == 8){
    unsigned char R = (X - (Y / 2) + 128);
    *pOutput = R;
    CALCULATE_CRC_BYTE
    *pOutput = (unsigned char) (R + Y);
    CALCULATE_CRC_BYTE
   }else
    if (pWaveFormatEx->wBitsPerSample == 24){
     __int32 RV, LV;
     unsigned __int32 nTemp = 0;

     RV = X - (Y / 2);
     LV = RV + Y;


     if (RV < 0)
      nTemp = ((unsigned __int32) (RV + 0x800000)) | 0x800000;
     else
      nTemp = (unsigned __int32) RV;

     *pOutput = (unsigned char) ((nTemp >> 0) & 0xFF);
     CALCULATE_CRC_BYTE
     *pOutput = (unsigned char) ((nTemp >> 8) & 0xFF);
     CALCULATE_CRC_BYTE
     *pOutput = (unsigned char) ((nTemp >> 16) & 0xFF);
     CALCULATE_CRC_BYTE

     nTemp = 0;
     if (LV < 0)
      nTemp = ((unsigned __int32) (LV + 0x800000)) | 0x800000;
     else
      nTemp = (unsigned __int32) LV;

     *pOutput = (unsigned char) ((nTemp >> 0) & 0xFF);
     CALCULATE_CRC_BYTE
     *pOutput = (unsigned char) ((nTemp >> 8) & 0xFF);
     CALCULATE_CRC_BYTE
     *pOutput = (unsigned char) ((nTemp >> 16) & 0xFF);
     CALCULATE_CRC_BYTE
    }
 }else
  if (pWaveFormatEx->nChannels == 1){
   if (pWaveFormatEx->wBitsPerSample == 16){
    __int16 R = X;

    *(__int16 *) pOutput = (__int16) R;
    CALCULATE_CRC_BYTE
    CALCULATE_CRC_BYTE
   }else
    if (pWaveFormatEx->wBitsPerSample == 8){
     unsigned char R = X + 128;
     *pOutput = R;
     CALCULATE_CRC_BYTE
    }else
     if (pWaveFormatEx->wBitsPerSample == 24){
      __int32 RV = X;
      unsigned __int32 nTemp = 0;

      if (RV < 0)
       nTemp = ((unsigned __int32) (RV + 0x800000)) | 0x800000;
      else
       nTemp = (unsigned __int32) RV;

      *pOutput = (unsigned char) ((nTemp >> 0) & 0xFF);
      CALCULATE_CRC_BYTE
      *pOutput = (unsigned char) ((nTemp >> 8) & 0xFF);
      CALCULATE_CRC_BYTE
      *pOutput = (unsigned char) ((nTemp >> 16) & 0xFF);
      CALCULATE_CRC_BYTE
     }
  }
}

#ifdef BACKWARDS_COMPATIBILITY

int apedec_UnprepareOld(int *pInputX,int *pInputY,int nBlocks,struct tWAVEFORMATEX *pWaveFormatEx,unsigned char *pRawData,unsigned int *pCRC,int *pSpecialCodes,int nFileVersion)
{
 //the CRC that will be figured during decompression
 unsigned __int32 CRC = 0xFFFFFFFF;

 //decompress and convert from (x,y) -> (l,r)
 //sort of int and ugly.... sorry
 if (pWaveFormatEx->nChannels == 2){
  //convert the x,y data to raw data
  if (pWaveFormatEx->wBitsPerSample == 16){
   __int16 R;
   unsigned char *Buffer = &pRawData[0];
   int *pX = pInputX;
   int *pY = pInputY;

   for (; pX < &pInputX[nBlocks]; pX++, pY++){
    R = *pX - (*pY / 2);

    *(__int16 *) Buffer = (__int16) R;
    CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];
    CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];

    *(__int16 *) Buffer = (__int16) R + *pY;
    CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];
    CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];
   }
  }else
   if (pWaveFormatEx->wBitsPerSample == 8){
    unsigned char *R = (unsigned char *) &pRawData[0];
    unsigned char *L = (unsigned char *) &pRawData[1];

    if (nFileVersion > 3830){
     int SampleIndex;
     for (SampleIndex = 0; SampleIndex < nBlocks; SampleIndex++, L+=2, R+=2){
      *R = (unsigned char) (pInputX[SampleIndex] - (pInputY[SampleIndex] / 2) + 128);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *R];
      *L = (unsigned char) (*R + pInputY[SampleIndex]);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *L];
     }
    }else{
     int SampleIndex;
     for (SampleIndex = 0; SampleIndex < nBlocks; SampleIndex++, L+=2, R+=2){
      *R = (unsigned char) (pInputX[SampleIndex] - (pInputY[SampleIndex] / 2));
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *R];
      *L = (unsigned char) (*R + pInputY[SampleIndex]);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *L];
     }
    }
   }else
    if (pWaveFormatEx->wBitsPerSample == 24){
     unsigned char *Buffer = (unsigned char *) &pRawData[0];
     __int32 RV, LV;
     int SampleIndex;

     for (SampleIndex = 0; SampleIndex < nBlocks; SampleIndex++){
      unsigned __int32 nTemp = 0;
      RV = pInputX[SampleIndex] - (pInputY[SampleIndex] / 2);
      LV = RV + pInputY[SampleIndex];

      if (RV < 0)
       nTemp = ((unsigned __int32) (RV + 0x800000)) | 0x800000;
      else
       nTemp = (unsigned __int32) RV;

      *Buffer = (unsigned char) ((nTemp >> 0) & 0xFF);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];

      *Buffer = (unsigned char) ((nTemp >> 8) & 0xFF);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];

      *Buffer = (unsigned char) ((nTemp >> 16) & 0xFF);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];

      nTemp = 0;
      if (LV < 0)
       nTemp = ((unsigned __int32) (LV + 0x800000)) | 0x800000;
      else
       nTemp = (unsigned __int32) LV;

      *Buffer = (unsigned char) ((nTemp >> 0) & 0xFF);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];

      *Buffer = (unsigned char) ((nTemp >> 8) & 0xFF);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];

      *Buffer = (unsigned char) ((nTemp >> 16) & 0xFF);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];
     }
    }
 }else
  if (pWaveFormatEx->nChannels == 1){
   //convert to raw data
   if (pWaveFormatEx->wBitsPerSample == 8){
    unsigned char *R = (unsigned char *) &pRawData[0];
    int SampleIndex;

    if (nFileVersion > 3830){
     for (SampleIndex = 0; SampleIndex < nBlocks; SampleIndex++, R++){
      *R = pInputX[SampleIndex] + 128;
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *R];
     }
    }else{
     for (SampleIndex = 0; SampleIndex < nBlocks; SampleIndex++, R++){
      *R = (unsigned char) (pInputX[SampleIndex]);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *R];
     }
    }
   }else
    if (pWaveFormatEx->wBitsPerSample == 24){
     unsigned char *Buffer = (unsigned char *) &pRawData[0];
     __int32 RV;
     int SampleIndex;

     for (SampleIndex = 0; SampleIndex<nBlocks; SampleIndex++){
      unsigned __int32 nTemp = 0;
      RV = pInputX[SampleIndex];


      if (RV < 0)
       nTemp = ((unsigned __int32) (RV + 0x800000)) | 0x800000;
      else
       nTemp = (unsigned __int32) RV;

      *Buffer = (unsigned char) ((nTemp >> 0) & 0xFF);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];

      *Buffer = (unsigned char) ((nTemp >> 8) & 0xFF);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];

      *Buffer = (unsigned char) ((nTemp >> 16) & 0xFF);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];
     }
    }else{
     unsigned char *Buffer = &pRawData[0];
     int SampleIndex;

     for (SampleIndex = 0; SampleIndex < nBlocks; SampleIndex++){
      *(__int16 *) Buffer = (__int16) (pInputX[SampleIndex]);
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];
      CRC = (CRC >> 8) ^ CRC32_TABLE[(CRC & 0xFF) ^ *Buffer++];
     }
    }
  }

  CRC = CRC ^ 0xFFFFFFFF;

  *pCRC = CRC;

  return 0;
}

#endif // BACKWARDS_COMPATIBILITY
