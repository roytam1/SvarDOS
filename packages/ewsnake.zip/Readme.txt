--- Inizio di README.TXT ---

EW Snake - Versione 0.5
Copyright (C) 2001 di Federico Marverti (yfede)

Questo programma � software libero; � lecito redistribuirlo o
modificarlo secondo i termini della Licenza Pubblica Generica GNU
come � pubblicata dalla Free Software Foundation; o la versione 2
della licenza o (a propria scelta) una versione successiva.
Questo programma � distribuito nella  speranza che sia  utile, ma
SENZA ALCUNA GARANZIA; senza neppure la garanzia implicita di
NEGOZIABILIT� o di APPLICABILIT� PER UN PARTICOLARE SCOPO. Si
veda la Licenza Pubblica Generica GNU per avere maggiori dettagli.

Questo programma deve essere distribuito assieme ad una copia
della Licenza Pubblica Generica GNU; in caso contrario, se ne pu�
ottenere una scrivendo alla Free Software Foundation, Inc., 59
Temple Place, Suite 330, Boston, MA 02111-1307 USA

Si puo` trovare una copia del testo originale della Licenza
Pubblica Generica (GNU General Public License) nel file 
License.txt. Una traduzione italiana non ufficiale e pertanto senza
alcun valore legale di suddetta licenza e` invece presente nel file
Licenza.txt.
In caso il testo originale della Licenza Pubblica Generica GNU non
sia stato distribuito o non sia disponibile e` possibile contattare
l'autore del programma all'indirizzo e-mail che segue:
                  yfede@tiscalinet.it
Lo stesso testo puo` inoltre essere scaricato dal sito ufficiale
della Free Software Foundation:
                  www.fsf.org
                  
--- Fine di README.TXT ---
                  