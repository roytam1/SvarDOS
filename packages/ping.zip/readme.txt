This source code of the ping tool has been extracted from the Watt-32 v2.2 software suite.
