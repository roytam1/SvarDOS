#ifdef DEBUG40
  g->d1 = TCcount;
  g->d2 = ResponseTime;
  g->d3 = ExtraTime;
  g->d4 = TCleft;
  g->d5 = et;
  g->d6 = hint;
  g->d7 = whichway;
#endif
