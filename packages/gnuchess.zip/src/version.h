/*
 * This is GNU Chess.
 * Copyright (c) 1986-1992 Free Software Foundation.
 *
 */
char *version = "4.00";
char *patchlevel = "60";
