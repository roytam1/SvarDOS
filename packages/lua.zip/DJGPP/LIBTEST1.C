#include <math.h>
#include "../src/lua.h"

int lib_compute_sin(lua_State *L)
{
  double argument = lua_tonumber(L, 1);
  lua_pushnumber(L, sin(argument));

  return 1;  /* One element returned on stack. */
}

int lib_compute_cos(lua_State *L)
{
  double argument = lua_tonumber(L, 1);
  lua_pushnumber(L, cos(argument));

  return 1;  /* One element returned on stack. */
}
