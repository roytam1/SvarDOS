
#ifndef DATA_H
#define DATA_H

extern ret_code   data_dir( int, struct asm_tok[], struct asym * );

#endif
