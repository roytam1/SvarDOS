/****************************************************************************
*
* Description:  prototypes for cpumodel.c
*
****************************************************************************/


#ifndef _CPUMODEL_H_INCLUDED_
#define _CPUMODEL_H_INCLUDED_

extern ret_code   SetCPU( enum cpu_info );

#endif
