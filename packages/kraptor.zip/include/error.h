// -------------------------------------------------------- 
// error.h 
// -------------------------------------------------------- 
// Copyright (c) Kronoman 
// En memoria de mi querido padre 
// -------------------------------------------------------- 
// Mensajes de error en modo texto.
// --------------------------------------------------------
#ifndef ERROR_H
#define ERROR_H

void levantar_error(char *msg);

#endif
