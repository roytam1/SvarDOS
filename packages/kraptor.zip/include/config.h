#ifndef KRAPTOR_CONFIG_H
#define KRAPTOR_CONFIG_H
void cargar_configuracion();
void salvar_configuracion();

#endif
