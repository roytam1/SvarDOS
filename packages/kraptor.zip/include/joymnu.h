/*
 --------------------------------------------------------
 joymnu.h
 Calibracion del joystick
 --------------------------------------------------------
*/
#ifndef JOYMNU_H
#define JOYMNU_H


void probar_el_joystick(int nj);
void dialog_joystick_calibrate(int nj);
void joystick_configuration_menu();



#endif
