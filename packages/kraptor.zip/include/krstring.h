// -------------------------------------------------------- 
// krstring.h
// -------------------------------------------------------- 
// Copyright (c) 2002, Kronoman 
// En memoria de mi querido padre 
// -------------------------------------------------------- 
// Funciones para strings ASCIIZ auxiliares
// -------------------------------------------------------- 
// ASCIIZ string function
// --------------------------------------------------------

#ifndef KRSTRING_H
#define KRSTRING_H

char *krtrim(char *dest, const char *orig);

#endif
