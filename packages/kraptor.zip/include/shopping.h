/*
 --------------------------------------------------------
 shopping.h
 --------------------------------------------------------
 Sistema de shopping de Kraptor 

 NOTAS: TODOS LOS TEXTOS DEL MENU ESTAN EN *INGLES*
 PARA PODER TRADUCIRLOS AUTOMATICAMENTE
 CON EL ENGINE DE TRADUCCION.
 USAR MENUES Y DIALOGOS *LOCALES* PARA QUE AL
 ENTRAR/SALIR DE SCOPE, (CADA VEZ QUE SE LLAMA LA FUNCION)
 SE TRADUZCAN AUTOMATICAMENTE AL LENGUAJE ORIGINAL.
 --------------------------------------------------------
*/

#ifndef SHOPPING_H
#define SHOPPING_H

extern BITMAP *shop_bmp;

void do_shopping_principal();



#endif
