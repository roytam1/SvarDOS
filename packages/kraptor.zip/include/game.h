#ifndef GAME_H
#define GAME_H

/* Prototipos */

void comenzar_juego(int);
 
 
#endif 
