// -------------------------------------------------------- 
// Kraptor - Call of the freedom
// --------------------------------------------------------
// main.h 
// -------------------------------------------------------- 
// Copyright (c) 2002, Kronoman 
// En memoria de mi querido padre 
// -------------------------------------------------------- 

#ifndef MAIN_H
#define MAIN_H

// Version del engine
#define KRAPTOR_VERSION_STR "1.0.2"

#endif
