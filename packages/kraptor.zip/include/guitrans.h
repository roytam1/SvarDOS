/*
guitrans.h
Por Kronoman
Copyrigth (c) 2002, Kronoman
En memoria de mi querido padre

Este modulo se encarga de traducir estructuras
de los GUI de Allegro al idioma actual.
*/

#ifndef GUITRANS_H
#define GUITRANS_H

#include <allegro.h>

void traducir_DIALOG_dp(DIALOG *d);
void traducir_MENU_text(MENU *d);

#endif
