/* 
test.c
This is a test program
The only purpose of this program is to check if you can compile Allegro programs.
By Kronoman - In lovin memory of my father - October 2003
*/

#include <allegro.h>
#include <aldumb.h>

int main()
{
    allegro_init();

    allegro_message("This is a test program to check if you can compile Allegro programs.\nYou can safely erase this program.\n");

return 0;
}
END_OF_MAIN();
