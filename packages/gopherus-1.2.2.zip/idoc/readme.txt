This folder contains the source files used to generate the internal Gopherus
documentation. Each file is converted to a char array and used to generate the
idoc.h declarations.

Note: The gopherus.txt file that is outside this directory is also combined
      into idoc.h
