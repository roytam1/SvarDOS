/*
 * This file is part of the Gopherus project.
 * Copyright (C) Mateusz Viste 2013-2022
 */

#ifndef VERSION_H
#define VERSION_H

#define pVer "1.2.2"
#define pDate "2013-2022"

#endif
