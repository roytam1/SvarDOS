#define UPX_VERSION_HEX         0x035b00        /* 03.91.00 */
#define UPX_VERSION_STRING      "3.91"
#define UPX_VERSION_STRING4     "3.91"
#define UPX_VERSION_DATE        "Sep 30th 2013"
#define UPX_VERSION_DATE_ISO    "2013-09-30"
#define UPX_VERSION_YEAR        "2013"
