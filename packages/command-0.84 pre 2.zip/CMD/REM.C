/* $Id: rem.c 1291 2006-09-05 01:44:33Z blairdude $
 *  REM -- includes comments "remarks" into batch scripts
 */

#include "../config.h"

#include "../include/command.h"

int cmd_rem (char * param) { (void)param; return 0; }
