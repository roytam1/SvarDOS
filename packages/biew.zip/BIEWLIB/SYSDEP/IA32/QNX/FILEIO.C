#define ftruncate(a,b) chsize(a,b)
#include "biewlib/sysdep/generic/posix/fileio.c"
