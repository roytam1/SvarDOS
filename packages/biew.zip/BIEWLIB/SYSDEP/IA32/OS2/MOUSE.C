#include "biewlib/sysdep/ia16/os2/mouse.c"
