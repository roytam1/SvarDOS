#include "biewlib/sysdep/ia16/dos/nls.c"
