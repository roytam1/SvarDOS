/* BEOS lacks posix timers */
