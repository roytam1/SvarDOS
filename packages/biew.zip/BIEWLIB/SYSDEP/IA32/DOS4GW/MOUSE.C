#define ax eax
#define bx ebx
#define cx ecx
#define dx edx
#define int86 int386
#include "biewlib/sysdep/ia16/dos/mouse.c"
