#define ax eax
#define bx ebx
#define cx ecx
#define dx edx
#define int86 int386
#define getvect _dos_getvect
#define setvect _dos_setvect
#include "biewlib/sysdep/ia16/dos/os_dep.c"
