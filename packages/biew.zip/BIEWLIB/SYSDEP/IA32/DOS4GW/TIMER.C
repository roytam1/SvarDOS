#define getvect _dos_getvect
#define setvect _dos_setvect
#include "biewlib/sysdep/ia16/dos/timer.c"
