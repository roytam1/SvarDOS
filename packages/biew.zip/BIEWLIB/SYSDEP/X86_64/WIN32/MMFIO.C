/* Note: Vista-64 requires porting for MMF file handling */
#include "biewlib/sysdep/ia16/dos/mmfio.c"
