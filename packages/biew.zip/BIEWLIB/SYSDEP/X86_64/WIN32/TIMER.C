#include "biewlib/sysdep/ia32/win32/timer.c"
