/**
 * @namespace   biewlib
 * @file        biewlib/sysdep/generic/posix/misc.c
 * @brief       Generic misc. functions
 * @version     -
 * @author      Nickols_K
 * @date        2003
**/
#include <string.h>
#include <stdio.h>
#include <unistd.h>

#include "biewlib/biewlib.h"

int __FASTCALL__ __inputRawInfo(char *head, char *text)
{
    return -1;
}
