/* Sorry! POSIX lacks mremap function. Only Linux has it. */
#include "biewlib/sysdep/ia16/dos/mmfio.c"
