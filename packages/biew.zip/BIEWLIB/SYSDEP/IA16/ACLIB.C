/* Empty for now */
static int dummy = 0;
