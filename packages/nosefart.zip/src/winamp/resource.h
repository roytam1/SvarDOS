//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by in_nsf.rc
//
#define IDD_ABOUT                       101
#define IDB_Nosefart                    102
#define IDD_CONFIG                      103
#define IDD_INFO                        104
#define IDB_BLADE                       106
#define IDC_ABOUT_EDIT                  1001
#define IDC_16BIT                       1001
#define IDC_8BIT                        1003
#define IDC_STEREO                      1004
#define IDC_MONO                        1005
#define IDC_CHECK1                      1006
#define IDC_CHECK2                      1007
#define IDC_CHECK3                      1008
#define IDC_CHECK4                      1009
#define IDC_CHECK5                      1010
#define IDC_CHECK6                      1011
#define IDC_DEF                         1012
#define IDC_WWWNOFRENDO                 1013
#define IDC_WWWZOPHAR                   1014
#define IDC_FREQ                        1015
#define IDC_THREAD                      1016
#define IDC_TEXT1                       1017
#define IDC_TEXT2                       1018
#define IDC_TEXT3                       1019
#define IDC_TEXT4                       1020
#define IDC_DSP                         1021
#define IDC_TEXT5                       1021
#define IDC_TEXT6                       1022
#define IDC_TEXT7                       1023
#define IDC_TEXT8                       1024
#define IDC_NOSEFARTSITE                1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
