#!/bin/bash
#
# Bash script to adjust the version number and dates of files.

./misc/fixver/teo.sh 1 8 2
./misc/fixver/cc90hfe.sh 0 5 0

echo "Done!"

