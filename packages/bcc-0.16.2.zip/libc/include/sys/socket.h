
#ifndef __SYS_SOCKET_H
#define __SYS_SOCKET_H
#include <features.h>
#include __SYSINC__(socket.h)
#endif
