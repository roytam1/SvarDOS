
This is Stella version 1.0b1.  It may have a few bugs in it, however, the 
X windows version is fairly complete and playable.  You will need a unix 
machine to build this version.  For more information see the 'Stella.txt' 
file.

If you find any problems please let me know.

Bradford W. Mott
bwmott@acm.org

