This directory contains a precompiled version of the picoTCP library for DOS.
See the URL below for details about picoTCP for DOS:

http://picotcp4dos.sourceforge.net
