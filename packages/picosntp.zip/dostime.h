/*
 * Functions to get/set date and time in DOS.
 *
 * This file is part of the picoSNTP project.
 * Copyright (C) 2015-2016 Mateusz Viste
 *
 * http://picosntp.sourceforge.net
 */

#ifndef DOSTIME_H_SENTINEL
#define DOSTIME_H_SENTINEL

void dostime_get(int *year, int *mon, int *day, int *h, int *m, int *s);
void dostime_set(int year, int mon, int day, int h, int m, int s);

#endif
