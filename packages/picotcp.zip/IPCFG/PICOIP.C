/*
 * This file is part of the ipcfg tool
 * http://picotcp4dos.sourceforge.net
 *
 * Copyright (C) 2015 Mateusz Viste
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <stdint.h> /* uint32_t */
#include <string.h> /* memset() */

#include "picoip.h" /* include self for control */


/* converts a picotcp IPv4 (as uint32_t) into ipcfg format */
void picoip2ip(uint32_t ip4, unsigned char *dst) {
  int i;
  memset(dst, 0, 10);
  memset(dst + 10, 0xff, 2);
  for (i = 12; i < 16; i++) {
    dst[i] = ip4 & 0xff;
    ip4 >>= 8;
  }
}
