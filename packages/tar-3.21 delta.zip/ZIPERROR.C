int ziperror = 0;
char *ziperrlist[] = {
   "uninitialized zip processing",
   "not enough memory",
   "bad magic header",
   "reserved field or compression method",
   "EOF while processing header",
   "EOF while reading zip data",
   "Invalid zip data",
   "More data to process at close",
   "uncompressed size differs from recorded",
   "bad CRC",
   "zip write error",
   "generic/internal error",
};
