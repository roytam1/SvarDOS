#!/bin/sh

zip -r ZXSpectr34src.zip . -i@list_src.lst

