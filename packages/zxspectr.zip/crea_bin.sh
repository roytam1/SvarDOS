#!/bin/sh

zip -r ZXSpectr34.zip . -i@list_bin.lst

