int find_str (char *sz, int thefile, int invert_search,
 int count_lines, int number_output, int ignore_case);
