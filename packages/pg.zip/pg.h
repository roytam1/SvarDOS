/*
  pg.h

  Header file for pg program

  (c) BearHeart

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  Revision Notes
                  bh 95.02.27  Initial Coding
   BAHCL 2003.10.30 - move assembly language related definitions to pgasm.asm
                    - convert keyboard scan code to word size
                    - clean up unused definitions
                    - migrated to Turbo C 2.01
*/

#define true (1)
#define false (0)

#define byte unsigned char
#define word unsigned int

/* video attributes */

#define BLACK   (0x00)
#define BLUE    (0x01)
#define GREEN   (0x02)
#define CYAN    (0x03)
#define RED     (0x04)
#define MAGENTA (0x05)
#define BROWN   (0x06)
#define WHITE   (0x07)
#define BRIGHT  (0x08)
/* #define BLINK   (0x80) */
#define YELLOW  (BROWN | BRIGHT)
#define UNDERLINE (0x01)  /* for MONO only */
#define MONO    (7)

#define ATTR(fg,bg)  (((bg) << 4) | (fg))

/* keyboard scan codes */ /* convert to word size for assembly routine */
#define PG_UP      (0x4900)
#define PG_DN      (0x5100)
#define KEY_HOME   (0x4700)
#define KEY_END    (0x4F00)
#define KEY_UP     (0x4800)
#define KEY_DN     (0x5000)
#define KEY_LT     (0x4B00)
#define KEY_RT     (0x4D00)
#define RETURN     (0x1C0D)
#define ESC        (0x011B)
#define QUIT       (0X2D00) /* Alt-x quit */
#define SPACE      (0x3920)
#define JUMPTO     (0x0E08) /* Backspace  Jump to a line number */

/*  to be replaced as countries with different ASCII code */
#define BITON      (0X42)   /* B Bit 7 on / off */
#define HEX        (0X48)   /* H Hex  */
#define NFILE      (0X4E)   /* N Next file */
#define PFILE      (0X50)   /* P Prev.file */
#define WRAP       (0X57)   /* W wrap */

/*  save book mark #1..0 map to key 1..0 */
#define SBM_MAX    10
#define SBM_1      (0x31)
#define SBM_2      (0x32)
#define SBM_3      (0x33)
#define SBM_4      (0x34)
#define SBM_5      (0x35)
#define SBM_6      (0x36)
#define SBM_7      (0x37)
#define SBM_8      (0x38)
#define SBM_9      (0x39)
#define SBM_0      (0x30)

/*  jump to book mark #1..0 map to key alt1..0 */
#define JBM_A1     (0x7800)
#define JBM_A2     (0x7900)
#define JBM_A3     (0x7A00)
#define JBM_A4     (0x7B00)
#define JBM_A5     (0x7C00)
#define JBM_A6     (0x7D00)
#define JBM_A7     (0x7E00)
#define JBM_A8     (0x7F00)
#define JBM_A9     (0x8000)
#define JBM_A0     (0x8100)
/*  reload file path #1..2 map to key alt9..0 GONE! */

#define KEY_F1     (0x3B00)   /* F1 show manual */
#define KEY_F2     (0x3C00)   /* F2 Search Backward (I) */
#define KEY_F3     (0x3D00)   /* F3 Search forward  (I) */
#define KEY_F4     (0x3E00)   /* F4 Search mode     (I) */
#define KEY_F5     (0x3F00)   /* F5 Save text from the screen to PG.SAV */
#define KEY_F6     (0x4000)   /* F6 Change foreground color */
#define KEY_F7     (0x4100)   /* F7 Change language font */
#define KEY_F8     (0x4200)   /* F8 Save history to PG.PG */
#define KEY_F9     (0x4300)   /* F9  reload files from argv[n-1] */
#define KEY_F10    (0x4400)   /* F10 reload files from argv[n+1] */
#define KEY_SF1    (0x5400)   /* S-F1 One Line Traditional Chinese Big5 */
#define KEY_SF2    (0x5500)   /* S-F2 Search Backward (S) */
#define KEY_SF3    (0x5600)   /* S-F3 Search forward  (S) */
#define KEY_SF4    (0x5700)   /* S-F4 Search history */
#define KEY_SF5    (0x5800)   /* S-F5 view save file */
#define KEY_SF6    (0x5900)   /* S-F6 Change backgound color */
#define KEY_SF7    (0x5A00)   /* S-F7 Change language font */
#define PGDOTPG    (0x5B00)   /* S-F8 Loads file from PG.PG */
#define SLAYPG_PG  (0x5C00)   /* S-F9 remove PG.PG */
#define SLAYPG_SAV (0x5D00)   /* S-F10 remove PG.SAV */
#define KEY_LFILE  (0x8400)   /* C-PageUp last file */
#define KEY_NFILE  (0x7600)   /* C-PageDn next file */
#define CHGVMODE   (0x1200)   /* Alt-E Change video mode */
#define DOSSHELL   (0x2000)   /* Alt-D DOS command shell */
#define NEW_FILE   (0x2100)   /* Alt-F New file spec. or load file from @file */


/* Symbolic constants */
#define MAXSIZELINE   (256)             /* maximum size of a line */
#define LIN_ADDRS     (1024)            /* # of line addresses in a group */
#define GRP_ADDRS     (1024)            /* # of groups to hold line addresses */
#define PANLIMIT      (176)
#define CO_STATUS     ATTR(BRIGHT | GREEN, MAGENTA)
#define CO_LO_STATUS  ATTR(GREEN,          MAGENTA)
#define CO_TEXT       ATTR(BRIGHT | CYAN,  BLACK)
#define MO_STATUS     ATTR(BLACK,          WHITE)
#define MO_LO_STATUS  ATTR(GREEN,          WHITE)   /* lower contrast  */
#define MO_TEXT       ATTR(BRIGHT | WHITE, BLACK)
#define TAB           (0x09)                        /* ASCII tab character */
#define CR            (0xD)
#define LF            (0xA)
#define TABSTOPS      (8)
#define STATOK        (0)                       /* s/b enum */
#define STATTOP       (1)
#define STATBOT       (2)
#define MAX_FILE      (256)
#define PATHLEN       (80 + 5)                  /* path + topline */


/* Local Functions */
void InitVideo(void);                           /* call this first */
int  newpath(char *);                           /* break down full path */
int  countfile(char *, long);                   /* count number of files */
int  getline(long);                             /* get a line from infile */
int  pagefile(long);                            /* user interface */
int  at_handler(int);                           /* @file handler */
void exptabs(void);                             /* expand tabstop */
void display(long);                             /* display file content */
void last_file();                               /* load previous file */
void next_file();                               /* load next file */

void chg_bg_color();                            /* change background color */
void chg_fg_color();                            /* change foreground color */
void new_file();                                /* to view new files */
void reload_argv_prev();                        /* reload files from previous argv */
void reload_argv_next();                        /* reload files from next argv */
void save_history(long);                        /* save history */
void save_screen(long, long);                   /* save screen to disk */
void slayer(char *);                            /* remove PG.SAV and PG.PG */
void mvaddnstr(int,int,int,char *);             /* print at only n char from str */
void usage(void);                               /* tell 'em how ta use it */
void errorexit(int, char *);                    /* error!! bail out! */
void headline(long);                            /* program head line */
void clearscreen(void);                         /* clear a screen */
void clearline(int, char);                      /* clear a line */
void line2offset(long);                         /* convert line # to offset */
void load_grp_li_addr(int);                     /* reload the line addresses of a group */
char *strfind(char *, char *);                  /* find substring */
char *strrfind(char *, char *);                 /* find substr backward */
void settextattr(char *);

/* Global Assembly language functions */
extern check_mouse(void);                       /* Setup mouse user routine */
extern reset_mouse(void);                       /* Reset mouse */
extern pickup_string(char *, int);              /* pick up a string with mouse */
extern cursor_x(char *, char *, int);           /* where cursor suppose to go */
extern mouseorkey(void);                        /* get mouse or keyboard scancode */
extern check_filespec(char *);                  /* check if filespec is valid */
extern mvaddch(int, int, int);                  /* position,char,attr */
extern getbiosinfo(void);                       /* get BIOS information */
extern getstr(char *);                          /* Get a string */
extern scroll_up(int,int,int,int,int);          /* scroll up N lines */
extern set_textattr(char *);
extern save_textattr(char *, char);
extern kbget(void);                             /* get keyboard scancode */
extern move(int, int);                          /* move cursor to */
extern iaca(long,int);                          /* intra app. comm. area */
extern read_infile(int, int);                   /* asm routine to read infile */
extern char *get_fname(int, char *, char *);    /* get file name from @file */
extern chg_vid_mode(void);                      /* change vga mode to 25/28/50 */
extern read_one_group(long);
extern get_one_line(long);                      /* getline */
