#ifndef CRUNCH_H_
#define CRUNCH_H_

BOOL CrunchVolume(RDWRHandle handle);

#endif
