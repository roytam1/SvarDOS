#ifndef MODULES_H_
#define MODULES_H_

int InfoFAT(void);
int CheckFAT(void);
int SortFAT(int criterium, int order);
int DefragFAT(int method);
int InspectLabelSizeFAT(void);

#endif
