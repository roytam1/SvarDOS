#ifndef _DPMITST_H
#define _DPMITST_H

int cdecl DPMIinstalled(void);

#endif
