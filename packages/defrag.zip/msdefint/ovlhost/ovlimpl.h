#ifndef MSDEFINT_IMPL_H_
#define MSDEFINT_IMPL_H_

void StartCounting(void);

void MSDEFINT_GetCallbacks(struct CallBackStruct* result);

#endif
