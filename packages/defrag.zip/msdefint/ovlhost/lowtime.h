#ifndef LOWTIME_H_
#define LOWTIME_H_

void cdecl GetTime(int* hour, int* minute, int* second);

#endif
