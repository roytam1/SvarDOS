#ifndef FRAME_H_
#define FRAME_H_

struct Frame {

  char* caption;

  int xlen;
  int ylen;
};

#endif
