#ifndef LOGMAN_H_
#define LOGMAN_H_

void LogPrint(char* text); 

void ScrLogPrint(char* text); 

void ShowScreenLog(void);

#define MAINPAGE 0
#define LOGPAGE  1

#endif
