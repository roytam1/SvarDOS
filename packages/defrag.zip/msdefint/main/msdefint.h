#ifndef MSDEFINT_H_
#define MSDEFINT_H_

int MSDefint(int argc, char *argv[]);

#endif
