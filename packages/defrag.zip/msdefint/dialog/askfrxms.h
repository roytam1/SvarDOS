#ifndef ASKXMSMANAGER_H_
#define ASKXMSMANAGER_H_

int AskForXMSManager(void);

#endif
