#ifndef METHODS_H_
#define METHODS_H_

typedef int Method;

int AskOptimizationMethod(Method* method, BOOL bForFAT32);

#endif
