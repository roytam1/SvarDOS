#ifndef MAPLEGEND_H_
#define MAPLEGEND_H_

void ShowMapLegend(void);

#endif
