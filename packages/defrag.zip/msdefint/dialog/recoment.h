#ifndef RECOMMENT_H_
#define RECOMMENT_H_

int RecommendMethod(int fragmentation, char drive, char* recommendation);

#endif
