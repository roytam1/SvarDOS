#ifndef STOP_DEFRAG_H_
#define STOP_DEFRAG_H_

int QueryUserStop(void);

#endif
