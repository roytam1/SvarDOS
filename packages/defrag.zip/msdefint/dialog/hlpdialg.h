#ifndef HELP_DIALOG_H_
#define HELP_DIALOG_H_

void ShowHelpSystem(void);

#endif
