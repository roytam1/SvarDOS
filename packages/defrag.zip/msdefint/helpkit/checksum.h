#ifndef CHECKSUM_H_
#define CHECKSUM_H_

unsigned CalculateCheckSum(char* file);

#endif