#ifndef INDEX_STACK_H_
#define INDEX_STACK_H_

#define STACK_DEPTH 10

void PushHelpIndex(int index);
int  PopHelpIndex(void);
int  TopHelpIndex(void);

#endif
