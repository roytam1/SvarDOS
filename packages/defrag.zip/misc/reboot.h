#ifndef REBOOT_H_
#define REBOOT_H_

void WarmReboot(void);
void ColdReboot(void);

#endif
