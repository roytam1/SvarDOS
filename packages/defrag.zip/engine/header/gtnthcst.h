#ifndef GET_NTH_CLUSTER_H_
#define GET_NTH_CLUSTER_H_

BOOL GetNthCluster(RDWRHandle handle, CLUSTER n, CLUSTER* label);

#endif
