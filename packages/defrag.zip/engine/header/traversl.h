#ifndef TRAVERSALS_H_
#define TRAVERSALS_H_

#define FAIL -1

#define STOP FALSE
#define NEXT TRUE

#endif
