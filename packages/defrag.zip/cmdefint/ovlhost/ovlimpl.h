#ifndef CMDEFINT_IMPL_H_
#define CMDEFINT_IMPL_H_

void CMDEFINT_GetCallbacks(struct CallBackStruct* result);

#endif
