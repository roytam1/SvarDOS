#ifndef CHECKOS_H_
#define CHECKOS_H_

int CheckOS(void);

#endif
