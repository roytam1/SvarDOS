#ifndef CMDEFINT_H_
#define CMDEFINT_H_

int CMDefint(int argc, char *argv[]);

#endif
