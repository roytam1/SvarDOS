#ifndef MODULE_GATE_H_
#define MODULE_GATE_H_

int OptimizeDisk(void);
int ScanDrive(void);
int SortDirectories (void);
int CheckDiskIntegrity(void);

#endif
