/* state.h */
/* Copyright 1995 by Steve Kirkendall */



typedef unsigned ELVISSTATE;
typedef struct state_s STATE;
