/* display.h */
/* Copyright 1995 by Steve Kirkendall */


typedef void DMINFO;
typedef struct dispmode_s DISPMODE;
