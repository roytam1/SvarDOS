/* message2.h */

BEGIN_EXTERNC
extern void msgscriptline P_((MARK mark, char *name));
END_EXTERNC
