#ifndef NASM_VERSION_H
#define NASM_VERSION_H
#define NASM_MAJOR_VER      2
#define NASM_MINOR_VER      16
#define NASM_SUBMINOR_VER   1
#define NASM_PATCHLEVEL_VER 0
#define NASM_VERSION_ID     0x02100100
#define NASM_VER            "2.16.01"
#endif /* NASM_VERSION_H */
