#ifndef LONG_FILENAME_H_
#define LONG_FILENAME_H_

unsigned char CalculateSFNCheckSum(struct DirectoryEntry* entry);

#endif
