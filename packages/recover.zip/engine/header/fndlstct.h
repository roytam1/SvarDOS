#ifndef FIND_LAST_FREE_CLUSTER_H_
#define FIND_LAST_FREE_CLUSTER_H_

BOOL FindLastFreeCluster(RDWRHandle handle, CLUSTER* result);

#endif
