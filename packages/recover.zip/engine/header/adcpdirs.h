#ifndef ADAPT_CURRENT_AND_PREVIOUS_H_
#define ADAPT_CURRENT_AND_PREVIOUS_H_

BOOL AdaptCurrentAndPreviousDirs(RDWRHandle handle,
                                 CLUSTER oldcluster,
                                 CLUSTER newcluster);


#endif
