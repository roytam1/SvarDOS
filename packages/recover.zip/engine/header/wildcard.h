#ifndef WILDCARD_H_
#define WILDCARD_H_

BOOL MatchWildcard(char* joker, char* filename, char* extension);

#endif
