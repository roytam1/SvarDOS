#ifndef RELOCATE_CLUSTER_H_
#define RELOCATE_CLUSTER_H_

BOOL RelocateCluster(RDWRHandle handle, CLUSTER source, CLUSTER destination);

#endif
