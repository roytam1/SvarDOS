#ifndef CALCULATE_FILESIZE_H_
#define CALCULATE_FILESIZE_H_

unsigned long CalculateFileSize(RDWRHandle handle, CLUSTER firstcluster);

#endif
