#ifndef LOW_STACK_D_
#define LOW_STACK_D_

int  low_pushd(void);
int  low_popd(void);
void low_popall(void);
int  low_topd(void);

#endif

