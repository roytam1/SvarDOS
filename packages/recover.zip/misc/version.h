#ifndef VERSION_H_
#define VERSION_H_

#define VERSION "beta 0.1"

#endif
