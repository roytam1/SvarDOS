ed math.h <<EOS-EOS
1,1s/^/"/
1,\$s/\$/\\\\/
\$,\$d
\$,\$s/\\\\\$/"/
w
q
EOS-EOS
