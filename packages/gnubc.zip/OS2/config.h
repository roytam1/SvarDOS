/* config.h */
#define NO_UNISTD
/* #define BC_MATH_FILE "libmath.b" */
