main()
{
	printf("hello world\n");
}