char _far *truename(char _far *dst, char _far *src);
					/* Returns the full path of a filename */
char *unix2dos(char *path);		/* Converts '/' to '\' in a filename */
char get_switch_character(void);	/* Returns the DOS switch character */
