struct LFNFindData
{
	unsigned long attributes;
	unsigned long CreationTime[2];
	unsigned long AccesstionTime[2];
	unsigned long ModificationTime[2];
	unsigned long FileSize;
	unsigned long FileSizeHigh;
	unsigned char reserved[8];
	unsigned char FullName[260]; 
	unsigned char ShortName[14]; 
} ;                     

int supportsLFN(char driveLetter);	/* Returns 0 if unsupported, 1 if probably supported */

char *getLFNname(char *fullpath);
					/* Returns LFN for a short name, NULL if unsupported */
char *lfntruename(char *longname, char *shortname);
int getLFNinfo(char *fullpath, struct LFNFindData LFNEntry);
					/* Returns 0 if unsupported, 1 if supported */
