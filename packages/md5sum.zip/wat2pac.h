#ifndef __PAC2WAT_H__
#define __PAC2WAT_H__

#ifdef __PACIFIC__

struct find_t {
   char   reserved[21];
   char   attrib;
   unsigned short  wr_time;
   unsigned short  wr_date;
   unsigned long   size;
   char   name[13];
};

#define _far far
#define __far far

#define _MAX_PATH 144
#define PATH_MAX 144
#define _MAX_DRIVE 3
#define _MAX_DIR 130
#define _MAX_FNAME 9
#define _MAX_EXT 5
#define _MAX_NAME 13

#define _find_t find_t

#define _A_NORMAL 0x00
#define _A_RDONLY 0x01
#define _A_HIDDEN 0x02
#define _A_SYSTEM 0x04
#define _A_VOLID  0x08
#define _A_SUBDIR 0x10
#define _A_ARCH   0x20

#define WILDCARDS 0x01
#define EXTENSION 0x02
#define FILENAME 0x04
#define DIRECTORY 0x08
#define DRIVE 0x10

#define R_OK 4
#define W_OK 2
#define X_OK 1
#define F_OK 0

#define S_IRUSR S_IREAD
#define S_IWUSR S_IWRITE
#define S_IXUSR S_IEXEC
#define S_ISBLK( m )  0
#define S_ISFIFO( m ) (((m) & S_IFMT) == S_IFFIFO)
#define S_ISCHR( m )  (((m) & S_IFMT) == S_IFCHR)
#define S_ISDIR( m )  (((m) & S_IFMT) == S_IFDIR)
#define S_ISREG( m )  (((m) & S_IFMT) == S_IFREG)

#define _dos_findclose(x)

#define getcwd(x,y) getcurrentworkingdirectory(x,y)

char *strrev(char *s);
int _dos_findfirst(char *name, int attr, struct find_t *ff);
int _dos_findnext(struct find_t *ff);
void setdta(char far *dta);
char far *getdta(void);
int fnsplit(const char *path, char *drive, char *dir, char *name, char *ext);
char *_getdcwd(int drive, char *dest, int len);
char *getcurrentworkingdirectory(char *dest, int len);
int _getdrive(void);
void _dos_getdrive(unsigned *drive);
void _dos_setdrive(unsigned a, unsigned *total);
int snprintf(char *dest_string, int maxlen, const char *format_string, ...);

#endif

#endif
