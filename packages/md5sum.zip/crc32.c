/*
* see PNG specification or ISO-3309 for details
*/
#ifdef USE_CRC
#define CRC32 1
#include "crc.h"
unsigned long update_crc32(const char *buf, int n, unsigned long crc)
{
	register int i;
	crc ^= 0xffffffff;
	for (i=0;i<n; i++) {
		crc = crc_table[0xff & (buf[i] ^ crc)] ^ (crc >> 8);
	}
	return crc ^= 0xffffffff;;
}
#endif
