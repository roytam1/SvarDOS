#ifdef USE_LFN
#include <dos.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "lfn.h"

int supportsLFN(char driveLetter)
{
  static char rootname[] = "X:\\";
  char buffer[32];
  union REGS r;
  struct SREGS sr;
  
  *rootname = driveLetter;

  r.x.ax = 0x71A0; /* get volume information */
  sr.ds = FP_SEG(rootname);
  r.x.dx = FP_OFF(rootname);
  sr.es = FP_SEG(buffer);
  r.x.di = FP_OFF(buffer);
  r.x.cx = sizeof(buffer);
  int86x(0x21, &r, &r, &sr);

/* if carry or LFN function unsupportd or volume does NOT support LFN functions */
  if (r.x.cflag || r.x.ax==0x7100) return 0;	/* return definitely unsupported */
  return 1;					/* else give it a go, ie probably supported */
}

/*char *getLFNname(char *fullpath)
{
	union REGPACK r;
	struct LFNFindData LFNEntry;

	r.w.ax = 0x714e;
	r.w.cx = 0xff;
	r.w.si = 1;
	r.w.ds = FP_SEG(fullpath);
	r.w.dx = FP_OFF(fullpath);
	r.w.es = FP_SEG(&LFNEntry);
	r.w.di = FP_OFF(&LFNEntry);
	intr(0x21, &r);
	
	if(r.w.flags & 1) {
		return NULL;
	}
	
	r.w.bx = r.w.ax;*/	/* close handle */
/*	r.w.ax = 0x71a1;
	intr(0x21,&r);
	return(LFNEntry.FullName);
}*/

char *lfntruename(char *longname, char *shortname)
{
	union REGS r;
	struct SREGS sr;
	r.x.ax = 0x7160;
	r.h.cl = 0x02;
	sr.ds = FP_SEG(shortname);
	r.x.si = FP_OFF(shortname);
	sr.es = FP_SEG(longname);
	r.x.di = FP_OFF(longname);
	intdosx(&r, &r, &sr);
	return (r.x.cflag & 1) ? NULL : longname;
}

/*int getLFNinfo(char *fullpath, struct LFNFindData LFNEntry)
{
	union REGPACK r;

	r.w.ax = 0x714e;
	r.w.cx = 0xff;
	r.w.si = 1;
	r.w.ds = FP_SEG(fullpath);
	r.w.dx = FP_OFF(fullpath);
	r.w.es = FP_SEG(&LFNEntry);
	r.w.di = FP_OFF(&LFNEntry);
	intr(0x21, &r);
	
	if(r.w.flags & 1) {
		return 0;
	}
	
	r.w.bx = r.w.ax;*/	/* close handle */
/*	r.w.ax = 0x71a1;
	intr(0x21,&r);
	return 1;
}*/
#endif
