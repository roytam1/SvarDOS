/* $Id: io95_loc.h 1.1 2000/01/11 09:34:51 ska Exp ska $
   $Locker: ska $	$Name:  $	$State: Exp $

	Local functions of the IO95 library

   $Log: io95_loc.h $
   Revision 1.1  2000/01/11 09:34:51  ska
   Initial revision

*/

#ifndef __IO95_LOC_H
#define __IO95_LOC_H

#if defined(__WATCOMC__)
#define DOSREGPACK union REGPACK
#define r_ds w.ds
#define r_dx w.dx
#define r_ax w.ax
#define r_es w.es
#define r_bx w.bx
#define r_cx w.cx
#define r_cl h.cl
#define r_bl h.bl
#define r_si w.si
#define r_di w.di
#define r_flags w.flags
#elif defined(__PACIFIC__)
#define DOSREGPACK union REGPACK
#define r_ds x.ds
#define r_dx x.dx
#define r_ax x.ax
#define r_es x.es
#define r_bx x.bx
#define r_cx x.cx
#define r_cl h.cl
#define r_bl h.bl
#define r_si x.si
#define r_di x.di
#define r_flags x.flags
#else
#define DOSREGPACK struct REGPACK
#endif

int callDosandWin95(int winfct, int dosfct, union REGS *rp, struct SREGS *sp);
int callWin95(int fct, DOSREGPACK * const rp);
/*	Invoke Win95/DOS function fct. It assumes that both APIs are the
	same except for the function number itself.

	*rp will hold the values of the successful call (either Win95
	or DOS).

	Return:
		0: success
		else: failure
*/


#endif
