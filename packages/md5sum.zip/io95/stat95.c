/*	int stat95(const char *fnam, struct stat *buf )

	Returns information about a file
*/

#ifdef USE_LFN

#ifdef __PACIFIC__
#include <stat.h>
#else
#include <sys/stat.h>
#endif
#include <stdio.h>
#include "io95.h"

int stat95(const char *fnam, struct stat *buf)
{
	char *shortname = NULL;
	lfn2sfn95(fnam, shortname);
	return stat(shortname, buf);
}

#endif
