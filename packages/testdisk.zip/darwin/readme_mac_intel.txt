This Mac OS X version of TestDisk & PhotoRec should work on Intel processor
(Mac Book, Mac Pro...)

TestDisk & PhotoRec documentation can be found online:
- http://www.cgsecurity.org/wiki/TestDisk
- http://www.cgsecurity.org/wiki/PhotoRec
