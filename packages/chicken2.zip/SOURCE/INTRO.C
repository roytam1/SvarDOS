void put_text(short x_pos, short y_pos, char *text, char font_nr, char *mem);
char *text, *text2;

void intro(void) {
  short c;
  FILE *infile;
  char *bcpal, *bclogo;

  bcpal = allocate_mem(768);
  bclogo = allocate_mem(64000);
  text = allocate_mem(1000);
  text2 = allocate_mem(1500);
  load_pcx("data10.chk", backg, pal);
  load_pcx("data06.chk", bclogo, bcpal);
  load_font("data07.chk", 0);
  clear_screen(vrscr, 0);
  for (c = 0; c < 768; c++) pal2[c] = 0;

  infile = fopen("data08.chk", "rb");
  for (c = 0; c < 542; c++) {
    text[c] = fgetc(infile) - 100;
  }
  fclose(infile);
  text[542] = 0;

  infile = fopen("data09.chk", "rb");
  for (c = 0; c < 1085; c++) {
    text2[c] = fgetc(infile) - 100;
  }
  fclose(infile);
  text2[1085] = 0;

  // brainchild
  set_palette(pal2);
  copy_screen(video, bclogo);
  fade(pal2, bcpal, 20);
  getch();
  for (c = 0; c < 768; c++) pal2[c] = 63;
  //play_sample(sample[0].address, sample[0].length, 22000, 0, 0, 0, 64, 0);
  fade(bcpal, pal2, 2);
  clear_screen(video, 0);

  // story
  fade(pal2, pal, 10);
  put_text(60, 30, text, 0, vrscr);
  //play_sample(sample[0].address, sample[0].length, 22000, 0, 0, 0, 64, 0);
  fade(pal, pal2, 2);

  // logo
  copy_screen(video, backg);
  fade(pal2, pal, 10);
  getch();
  //play_sample(sample[0].address, sample[0].length, 22000, 0, 0, 0, 64, 0);
  fade(pal, pal2, 2);

  // mission
  clear_screen(vrscr, 0);
  clear_screen(video, 0);
  fade(pal2, pal, 10);
  put_text(5, 30, text2, 0, vrscr);
  play_sample(sample[0].address, sample[0].length, 22000, 0, 0, 0, 64, 0);
  fade(pal, pal2, 2);
  clear_screen(video, 0);

  free(text);
  free(text2);
  free(bcpal);
  free(bclogo);
}



void put_text(short x_pos, short y_pos, char *text, char font_nr, char *mem) {
  unsigned short x, y;
  unsigned char color;
  unsigned short doffs, soffs;
  short xpos, ypos;
  unsigned short pos = 0;
  unsigned char c;
  unsigned short length;
  length = font[font_nr].height * font[font_nr].width;
  xpos = x_pos; ypos = y_pos;

  while ((c = text[pos]) != 0) {
    if (c == '*') {
      ypos += (font[font_nr].height + 1);
      xpos = x_pos;

    }
    else {
      soffs = c * length;
      doffs = (ypos << 8) + (ypos << 6) + xpos;

      for (y = 0; y < font[font_nr].height; y++) {
        for (x = 0; x < font[font_nr].width; x++) {
          color = font[font_nr].offset[soffs];
          if (color != 0) mem[doffs] = color;
          soffs++;
          doffs++;
        }
        doffs += (320 - font[font_nr].width);
      }
      xpos += font[font_nr].width;
    }
    pos++;

    if (kbhit()) break;

    wait_vertical_retrace();
    if (c != 32) play_sample(sample[1].address, sample[1].length, 44000, 0, 0, 0, 32, 0);
    copy_screen(video, mem);
  }

  getch();
}
